package com.nss.tobacco.activitymanagement;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.HashMap;
import java.util.Map;
@ContentView(R.layout.activity_add__yizai_guanli)
public class Add_YizaiGuanliActivity extends AppCompatActivity implements View.OnClickListener{
    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;

    @ViewInject(R.id.textView)
    TextView textView;
    @ViewInject(R.id.back_item)
    ImageView back_img;
    @ViewInject(R.id.phone_addmsg)
    ImageView take_photo;
    @ViewInject(R.id.photo1)
    ImageView photo1;
    @ViewInject(R.id.photo2)
    ImageView photo2;
    @ViewInject(R.id.photo3)
    ImageView photo3;

    @ViewInject(R.id.spinner_zhongzhihu)
    Spinner name;
    @ViewInject(R.id.spinner_yanmiaoleixing)
    Spinner leixing;
    @ViewInject(R.id.mianji_edit)
    EditText mianji;
    @ViewInject(R.id.hangju_edit)
    EditText hangju;
    @ViewInject(R.id.zhuju_edit)
    EditText zhuju;
    @ViewInject(R.id.spinner_gaimo)
    Spinner gaimo;
    @ViewInject(R.id.spinner_haichong)
    Spinner haichong;
    @ViewInject(R.id.spinner_fangshi)
    Spinner fangshi;
    @ViewInject(R.id.start_text)
    TextView dateText1;
    @ViewInject(R.id.end_text)
    TextView dateText2;
    @ViewInject(R.id.biaozhun_pic)
    ImageView biaozhun;
    @ViewInject(R.id.beizhu_edit)
    EditText beizhu;
    @ViewInject(R.id.btn_save)
    Button save;
    @ViewInject(R.id.btn_back)
    Button back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        map=new HashMap<>();
        initView();
        setDate();
        mySpinner();
        setListener();
    }
    private void initView() {
        textView.setText("移栽管理");
    }

    private void setListener() {
        back_img.setOnClickListener(this);
        take_photo.setOnClickListener(this);
        save.setOnClickListener(this);
        back_btn.setOnClickListener(this);
        getMianjiEditListener();
    }

    private void setDate() {
        //时间选择
        dateText1.setText(GetDate.lastDay());
        dateText1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_YizaiGuanliActivity.this);
                dialog.setDate(dateText1);
            }
        });
        dateText2.setText(GetDate.lastDay());
        dateText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_YizaiGuanliActivity.this);
                dialog.setDate(dateText2);
            }
        });
    }

    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.age, R.layout.item_myspinner);
        name.setAdapter(adapter1);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.leixing, R.layout.item_myspinner);
        leixing.setAdapter(adapter2);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,R.array.gaimo, R.layout.item_myspinner);
        gaimo.setAdapter(adapter3);
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,R.array.gaimo, R.layout.item_myspinner);
        haichong.setAdapter(adapter4);
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,R.array.yizaifangshi, R.layout.item_myspinner);
        fangshi.setAdapter(adapter5);
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.phone_addmsg:

                break;
            case R.id.btn_save:
                //uploadfile();
                //post();
                break;
            case R.id.btn_back:
                myDialog();
                break;
            default:
                break;
        }
    }
    public void getMianjiEditListener(){
        mianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
            @Override
            public void afterTextChanged(Editable s) {
                map.put("area",s);
                editStart = mianji.getSelectionStart();
                editEnd = mianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection = editStart;
                    mianji.setText(s);
                    mianji.setSelection(tempSelection);
                }
            }
        });

    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
