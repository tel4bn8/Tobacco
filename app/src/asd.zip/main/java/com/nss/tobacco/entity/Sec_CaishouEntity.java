package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建成熟采收的表
 */
@Table(name = "chengshucaishou")
public class Sec_CaishouEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "starttime")
    private String starttime;
    @Column(name = "endtime")
    private String endtime;
    @Column(name = "pick")
    private String pick;
    @Column(name = "same")
    private String same;
    @Column(name = "detail")
    private String detail;

    public Sec_CaishouEntity() {
    }

    public Sec_CaishouEntity(String id, String farmer, String starttime, String endtime, String pick, String same, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.starttime = starttime;
        this.endtime = endtime;
        this.pick = pick;
        this.same = same;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getPick() {
        return pick;
    }

    public void setPick(String pick) {
        this.pick = pick;
    }

    public String getSame() {
        return same;
    }

    public void setSame(String same) {
        this.same = same;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Sec_CaishouEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", starttime='" + starttime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", pick='" + pick + '\'' +
                ", same='" + same + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
