package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建揭膜培土的表
 */
@Table(name = "zhonggengpeitu")
public class Sec_JiemoEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "high")
    private String high;
    @Column(name = "basehigh")
    private String basehigh;
    @Column(name = "water")
    private String water;
    @Column(name = "mo")
    private String mo;
    @Column(name = "piece")
    private String piece;
    @Column(name = "area")
    private String area;
    @Column(name = "detail")
    private String detail;
    @Column(name = "smalltime")
    private String smalltime;
    @Column(name = "bigtime")
    private String bigtime;

    public Sec_JiemoEntity() {
    }

    public Sec_JiemoEntity(String id, String farmer, String high, String basehigh, String water, String mo, String area, String piece, String detail, String smalltime, String bigtime) {
        this.id = id;
        this.farmer = farmer;
        this.high = high;
        this.basehigh = basehigh;
        this.water = water;
        this.mo = mo;
        this.area = area;
        this.piece = piece;
        this.detail = detail;
        this.smalltime = smalltime;
        this.bigtime = bigtime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getHigh() {
        return high;
    }

    public void setHigh(String high) {
        this.high = high;
    }

    public String getBasehigh() {
        return basehigh;
    }

    public void setBasehigh(String basehigh) {
        this.basehigh = basehigh;
    }

    public String getWater() {
        return water;
    }

    public void setWater(String water) {
        this.water = water;
    }

    public String getMo() {
        return mo;
    }

    public void setMo(String mo) {
        this.mo = mo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPiece() {
        return piece;
    }

    public void setPiece(String piece) {
        this.piece = piece;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getSmalltime() {
        return smalltime;
    }

    public void setSmalltime(String smalltime) {
        this.smalltime = smalltime;
    }

    public String getBigtime() {
        return bigtime;
    }

    public void setBigtime(String bigtime) {
        this.bigtime = bigtime;
    }

    @Override
    public String toString() {
        return "Sec_JiemoEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", high='" + high + '\'' +
                ", basehigh='" + basehigh + '\'' +
                ", water='" + water + '\'' +
                ", mo='" + mo + '\'' +
                ", piece='" + piece + '\'' +
                ", area='" + area + '\'' +
                ", detail='" + detail + '\'' +
                ", smalltime='" + smalltime + '\'' +
                ", bigtime='" + bigtime + '\'' +
                '}';
    }
}
