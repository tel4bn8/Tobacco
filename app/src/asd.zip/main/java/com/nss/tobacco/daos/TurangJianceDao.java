package com.nss.tobacco.daos;

/**
 * Created by admin on 2016/11/3.
 */

public class TurangJianceDao {
}
