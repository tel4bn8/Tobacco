package com.nss.tobacco.activitymanagement;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CaremaAdapter;
import com.nss.tobacco.utils.CommonUtil;
import com.nss.tobacco.utils.Constants;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;
import com.nss.tobacco.utils.LocationUtils;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ContentView(R.layout.activity_add__miaoqi)
public class Add_MiaoqiActivity extends AppCompatActivity implements View.OnClickListener{


    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;


    Context mContext;
    private static final int CAREMA_REQUEST_CODE=1;//拍照请求码
    private String defaultPhotoPath=null;//拍照生成图片的默认绝对路径
    private String photoFolderPath=null;//存放照片的文件夹
    private int screenWidth=0;//屏幕宽度
    private String location2=null;//图片上的径纬度信息
    private boolean mCandelete=false; //图片是否可删除
    private List<String> mListPhotos;//存放拍摄图片路径
    private CaremaAdapter mCaremaAdapter=null;//存放图片的GridView的适配器


    @ViewInject(R.id.textView)
    TextView textView;//标题

    @ViewInject(R.id.back_item)
    ImageView back_img;//标题返回图片

    @ViewInject(R.id.second_ym_mq_add_imageView)
    ImageView take_photo;//图片图像

    @ViewInject(R.id.photo1)
    ImageView photo1;
    @ViewInject(R.id.photo2)
    ImageView photo2;

    @ViewInject(R.id.spinner_zhongzhihu)
    Spinner name;
    @ViewInject(R.id.bozhong_text)
    TextView bozhong;
    @ViewInject(R.id.chumiao_text)
    TextView chumiao;
    @ViewInject(R.id.jiandingmiao_text)
    TextView jiandingmiao;
    @ViewInject(R.id.jianye_text)
    TextView jianye;
    @ViewInject(R.id.lianmiao_text)
    TextView lianmiao;
    @ViewInject(R.id.spinner_miaoqing)
    Spinner miaoqing;
    @ViewInject(R.id.beizhu_edit)
    EditText beizhu;
    @ViewInject(R.id.btn_save)
    Button save;
    @ViewInject(R.id.btn_back)
    Button back_btn;
    @ViewInject(R.id.second_ym_mq_add_gridView)
    GridView photosGridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        mContext=this;
        map=new HashMap<>();
        initView();
        setDate();
        mySpinner();
        //初始化相机
        initCarema();
        setListener();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //requestpermisiion result , permission
    }
    private void initView() {
        textView.setText("苗期管理");
    }

    private void setListener() {
        back_img.setOnClickListener(this);
        take_photo.setOnClickListener(this);
        save.setOnClickListener(this);
        back_btn.setOnClickListener(this);
    }
    private void setDate() {
        //时间选择
        bozhong.setText(GetDate.lastDay());
        bozhong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_MiaoqiActivity.this);
                dialog.setDate(bozhong);
            }
        });
        chumiao.setText(GetDate.lastDay());
        chumiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_MiaoqiActivity.this);
                dialog.setDate(chumiao);
            }
        });
        jiandingmiao.setText(GetDate.lastDay());
        jiandingmiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_MiaoqiActivity.this);
                dialog.setDate(jiandingmiao);
            }
        });
        jianye.setText(GetDate.lastDay());
        jianye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_MiaoqiActivity.this);
                dialog.setDate(jianye);
            }
        });
        lianmiao.setText(GetDate.lastDay());
        lianmiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_MiaoqiActivity.this);
                dialog.setDate(lianmiao);
            }
        });
    }
    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.age, R.layout.item_myspinner);
        name.setAdapter(adapter1);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.miaoqing, R.layout.item_myspinner);
        miaoqing.setAdapter(adapter2);
    }
    private void initCarema() {
        defaultPhotoPath=CommonUtil.getSDPath()+ File.separator+"default.jpg";
        //获取屏幕分辨率
        DisplayMetrics dm=new DisplayMetrics();
        //取得窗口属性
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        //窗口的宽度
        screenWidth = dm.widthPixels;
        //是否可删除图片
        mCandelete=getIntent().getBooleanExtra("candelete",true);
        //获取文件夹名称
        if(getIntent().getStringExtra("folderName")==null){
            photoFolderPath=CommonUtil.getSDPath()+File.separator+"TestPhotoFolder";
        }else{
            photoFolderPath=getIntent().getStringExtra("folderName");
        }

    }
    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                myDialog();
                break;
            //调用系统拍照
            case R.id.second_ym_mq_add_imageView:
                 if(CommonUtil.getSDPath()==null){
                     Toast.makeText(Add_MiaoqiActivity.this, "请安装SD卡", Toast.LENGTH_SHORT).show();
                     return;
                 }
                //验证图片个数是否超出最大
                if(mListPhotos!=null&&mListPhotos.size()>= Constants.MAX_PHOTO_SIZE){
                    Toast.makeText(mContext, "最多只允许拍摄" + Constants.MAX_PHOTO_SIZE + "张照片。", Toast.LENGTH_SHORT).show();
                    return;
                }
                //调用系统拍照
                intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(defaultPhotoPath)));
                startActivityForResult(intent,CAREMA_REQUEST_CODE);
                break;
            case R.id.btn_save:
                break;
            case R.id.btn_back:
                myDialog();
                break;
            default:
                break;
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode== Activity.RESULT_OK){
            switch (requestCode){

                case CAREMA_REQUEST_CODE:
                    File folderAddr=new File(photoFolderPath);
                    //判断目录是否存在
                    if(!folderAddr.exists()||!folderAddr.isDirectory()){
                        folderAddr.mkdirs();
                    }
                    //将图片压缩到指定目录
                    String targetPath=photoFolderPath+File.separator+CommonUtil.getUUID32()+".jpg";
                    location2="东经: "+ LocationUtils.longitude + "北纬: "+LocationUtils.latitude+"  ";
                    //将图片压缩到指定目录并显示经纬度信息
                    boolean flag = CommonUtil.dealImage(defaultPhotoPath, targetPath, location2);
                    //删除图片原图
                    new File(defaultPhotoPath).delete();

                    //保存图片的绝对路径
                    if(mListPhotos==null){
                        mListPhotos=new ArrayList<>();
                    }
                    mListPhotos.add(targetPath);

                    if(mCaremaAdapter==null){
                        mCaremaAdapter=new CaremaAdapter(mContext,screenWidth,mListPhotos,mCandelete);
                        photosGridView.setAdapter(mCaremaAdapter);
                    }else{
                        mCaremaAdapter.notifyDataSetChanged();
                    }
                    break;
            }
        }

    }
    //返回按钮提醒框
    private void myDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
