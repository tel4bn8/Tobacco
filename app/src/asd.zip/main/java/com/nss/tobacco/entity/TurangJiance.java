package com.nss.tobacco.entity;

/**
 * Created by admin on 2016/11/1.
 */

public class TurangJiance {

}
