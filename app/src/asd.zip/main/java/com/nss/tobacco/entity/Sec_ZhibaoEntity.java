package com.nss.tobacco.entity;

import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建植保的表
 */
@Table(name = "zhibao")
public class Sec_ZhibaoEntity {
}
