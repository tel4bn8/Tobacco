package com.nss.tobacco.activityinfo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nss.tobacco.R;

public class PeixunXcActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peixun_xc);
    }
}
