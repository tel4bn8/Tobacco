package com.nss.tobacco.activitypreparation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CommonAdapter;
import com.nss.tobacco.adapter.ViewHolder;
import com.nss.tobacco.utils.DividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class YnYantianDaActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView imageViewback;
    private TextView textViewtitle, tvadd, tvupdata;
    private Spinner spinnerState;
    private EditText editTextsearch;
    private Button searchButton;
    private RecyclerView recyclerView;
    private List<String> mDatas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yn_yantian_da);

        initView();

        initListener();
        initData();
        initRecyclerView();
    }

    private void initData() {
        mDatas = new ArrayList<String>();
        for (int i = 'A'; i < 'z'; i++)
        {
            mDatas.add("" + (char) i);
        }
    }

    private void initRecyclerView() {
        recyclerView = (RecyclerView) findViewById(R.id.frm_first_yn_ytda_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //添加数据
        recyclerView.setAdapter(new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview, mDatas) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.id_num,s);
            }

            @Override
            public void onBindViewHolder(ViewHolder holder, final int position) {
                super.onBindViewHolder(holder, position);
                holder.setOnClickListener(R.id.id_num, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getApplicationContext(),"aaaaa"+position,Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        //分割线
        recyclerView.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL_LIST));

    }


    //初始化普通点击监听
    private void initListener() {
        imageViewback.setOnClickListener(this);

        tvadd.setOnClickListener(this);
        tvupdata.setOnClickListener(this);

        //搜索栏
        setMySpinnerLitsener();
        setMyEditLitsener();
        searchButton.setOnClickListener(this);
    }
    //设置输入监听
    private void setMyEditLitsener() {
        editTextsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    //设置spinner选择监听
    private void setMySpinnerLitsener() {
        spinnerState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    //初始化view
    private void initView() {
        //标题栏
        imageViewback = (ImageView) findViewById(R.id.back_item);
        textViewtitle = (TextView) findViewById(R.id.textView_item);
        textViewtitle.setText("烟田档案");
        tvadd = (TextView) findViewById(R.id.add_item);
        tvupdata = (TextView) findViewById(R.id.up_item);
        //搜索栏
        spinnerState = (Spinner) findViewById(R.id.frm_first_time_spinner);
        mySpinner();
        editTextsearch = (EditText) findViewById(R.id.frm_first_edittext);
        searchButton = (Button) findViewById(R.id.search_button_item);
    }

    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.caijizhuangtai, R.layout.item_myspinner);
        Spinner spinner = (Spinner) findViewById(R.id.frm_first_time_spinner);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_item:
                finish();
                break;
            case R.id.add_item:
                Intent intent = new Intent(YnYantianDaActivity.this, YnYantianDaAddActivity.class);
                startActivity(intent);
                break;
            case R.id.up_item:
                Toast.makeText(this,"上传成功",Toast.LENGTH_LONG).show();
                break;
            case R.id.frm_first_time_spinner:

                break;
            case R.id.frm_first_edittext:

                break;
            case R.id.search_button_item:

                break;
            default:
                break;
        }
    }
}
