package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.HashMap;
import java.util.Map;

@ContentView(R.layout.activity_ymh_ym_gc_add)
public class YmhYmGcAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;
    private boolean isSave = false;//是否保存

    @ViewInject(R.id.textView)
    private TextView textViewtitle;
    @ViewInject(R.id.back_item)
    private ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_ymh_ym_gc_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_dapengID)
    private EditText etGongchangID;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_textview_stop)
    private TextView tvStop;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_spinner_HomeAddress)
    private Spinner spHomeAddress;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_dapengNum)
    private EditText etDapengNum;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_dapengjiegou)
    private EditText etDapengjiegou;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_mianji)
    private EditText etMianji;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_yumiaoNum)
    private EditText etYumiaoNum;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_textview_inputTime)
    private TextView tvDengjiTime;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_dengjiren)
    private EditText etDengjiren;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_ymh_ym_gc_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_ymh_ym_gc_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        map=new HashMap<>();

        initView();
        initListener();
        setDate();
        mySpinner();
        setEditListener();
    }

    private void setEditListener() {
        etGongchangID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etGongchangID.getSelectionStart();
                editEnd = etGongchangID.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etGongchangID.setText(s);
                    etGongchangID.setSelection(tempSelection1);
                }
            }
        });
        etDapengNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etDapengNum.getSelectionStart();
                editEnd = etDapengNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etDapengNum.setText(s);
                    etDapengNum.setSelection(tempSelection1);
                }
            }
        });
        etDapengjiegou.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etDapengjiegou.getSelectionStart();
                editEnd = etDapengjiegou.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etDapengjiegou.setText(s);
                    etDapengjiegou.setSelection(tempSelection1);
                }
            }
        });
        etMianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etMianji.getSelectionStart();
                editEnd = etMianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etMianji.setText(s);
                    etMianji.setSelection(tempSelection1);
                }
            }
        });
        etYumiaoNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etYumiaoNum.getSelectionStart();
                editEnd = etYumiaoNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etYumiaoNum.setText(s);
                    etYumiaoNum.setSelection(tempSelection1);
                }
            }
        });
        etDengjiren.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etDengjiren.getSelectionStart();
                editEnd = etDengjiren.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etDengjiren.setText(s);
                    etDengjiren.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection1);
                }
            }
        });
    }

    private void mySpinner() {

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.xingzhengquhua, R.layout.item_myspinner);
        spHomeAddress.setAdapter(adapter2);
        String village = spHomeAddress.getSelectedItem().toString();
    }

    private void setDate() {
        String time = GetDate.lastDay();
        tvDengjiTime.setText(time);
        tvDengjiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YmhYmGcAddActivity.this);
                dialog.setDate(tvDengjiTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("育苗工场");
        //获取烟站、烟技员
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                if (isSave){
                    finish();
                }else {
                    myDialog();
                }
                break;
            case R.id.frm_first_ymh_ym_gc_add:
                Toast.makeText(YmhYmGcAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_ym_gc_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YmhYmGcAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_ym_gc_add_btnback:
                myDialog();
                break;
            default:
                break;
        }
    }
    //返回按钮
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//显示此对话框
    }
}
