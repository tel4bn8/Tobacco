package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.HashMap;
import java.util.Map;

@ContentView(R.layout.activity_wg_yanye_lh_add)
public class WgYanyeLhAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;
    private boolean isSave = false;//是否保存

    @ViewInject(R.id.textView)
    private TextView textViewtitle;
    @ViewInject(R.id.back_item)
    private ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_wg_yanye_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_wg_yanye_add_textview_wanggeID)
    private TextView tvWanggeID;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_K)
    private EditText etK;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_Cl)
    private EditText etCl;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_yanjian)
    private EditText etYanjian;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_huanyuantang)
    private EditText etHuanyuantang;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_zongtang)
    private EditText etZongtang;
    @ViewInject(R.id.frm_first_wg_yanye_add_textview_yanjiyuan)
    private TextView tvYanjiyuan;
    @ViewInject(R.id.frm_first_wg_yanye_add_textview_inputTime)
    private TextView tvDengjiTime;
    @ViewInject(R.id.frm_first_wg_yanye_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_wg_yanye_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_wg_yanye_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        x.view().inject(this);
        map=new HashMap<>();

        initView();
        initListener();
        
        setDate();
        
        setEditListener();
    }

    private void setEditListener() {
        etK.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etK.getSelectionStart();
                editEnd = etK.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etK.setText(s);
                    etK.setSelection(tempSelection1);
                }
            }
        });
        etCl.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etCl.getSelectionStart();
                editEnd = etCl.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etCl.setText(s);
                    etCl.setSelection(tempSelection1);
                }
            }
        });
        etYanjian.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etYanjian.getSelectionStart();
                editEnd = etYanjian.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etYanjian.setText(s);
                    etYanjian.setSelection(tempSelection1);
                }
            }
        });
        etHuanyuantang.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etHuanyuantang.getSelectionStart();
                editEnd = etHuanyuantang.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etHuanyuantang.setText(s);
                    etHuanyuantang.setSelection(tempSelection1);
                }
            }
        });
        etZongtang.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etZongtang.getSelectionStart();
                editEnd = etZongtang.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etZongtang.setText(s);
                    etZongtang.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection1);
                }
            }
        });

    }


    private void setDate() {
        String time = GetDate.lastDay();
        tvDengjiTime.setText(time);
        tvDengjiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(WgYanyeLhAddActivity.this);
                dialog.setDate(tvDengjiTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("烟叶理化");
        //获取网格编号

        //获取烟技员名字
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                if (isSave){
                    finish();
                }else {
                    myDialog();
                }
                break;
            case R.id.frm_first_wg_yanye_add:
                Toast.makeText(WgYanyeLhAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_wg_yanye_add_btnsave:
                Toast.makeText(WgYanyeLhAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_wg_yanye_add_btnback:
                if (isSave){
                    finish();
                }else {
                    myDialog();
                }
                break;
            default:
                break;
        }
    }
    //返回按钮
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//显示此对话框
    }

}
