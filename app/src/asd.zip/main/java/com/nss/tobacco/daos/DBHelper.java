package com.nss.tobacco.daos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * 测试
 */
public class DBHelper  extends SQLiteOpenHelper {

    public static final String DB_NAME = "tobacco.db";
    /*public static final String DB_TABLE_NAME = "xiaodu";*/
    private static final int DB_VERSION=1;
    public DBHelper(Context context) {
        //Context context, String name, CursorFactory factory, int version
        //factory输入null,使用默认值
        super(context, DB_NAME, null, DB_VERSION);
    }
    //数据第一次创建的时候会调用onCreate
    @Override
    public void onCreate(SQLiteDatabase db) {
        //创建表
        db.execSQL("CREATE TABLE IF NOT EXISTS xiaodu" +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT, farmer STRING,createtime STRING, yaopin STRING,sheshi STRING,detail STRING,state STRING)");
        db.execSQL("CREATE TABLE IF NOT EXISTS yantianguihua" +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT, village STRING,year STRING, area STRING,lng STRING,lat STRING," +
                "dixing STRING,tuzhi STRING,soil STRING,feili STRING,moditime STRING,technician STRING,detail STRING)");

        db.execSQL("CREATE TABLE IF NOT EXISTS miaochuangzhuifei"+
               "(id VARCHAR PRIMARY KEY, farmer STRING,type STRING,"+
                "num STRING,area STRING,way STRING,createtime STRING,detail STRING,state STRING,photopath STRING)"
        );
        db.execSQL("CREATE TABLE IF NOT EXISTS bingchongfangzhi"+
                "(id VARCHAR PRIMARY KEY,farmer STRING,yaopin STRING,nongdu STRING," +
                "way STRING,type STRING,rate STRING,area STRING,loss STRING,createtime STRING,detail STRING)");
    }
    //数据库第一次创建时onCreate方法会被调用，我们可以执行创建表的语句，当系统发现版本变化之后，会调用onUpgrade方法，我们可以执行修改表结构等语句
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //在表info中增加一列other
        //db.execSQL("ALTER TABLE info ADD COLUMN other STRING");
        Log.i("WIRELESSQA", "update sqlite "+oldVersion+"---->"+newVersion);
    }
}

