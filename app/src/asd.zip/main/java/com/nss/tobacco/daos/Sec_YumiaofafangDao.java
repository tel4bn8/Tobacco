package com.nss.tobacco.daos;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.nss.tobacco.MyApp;
import com.nss.tobacco.entity.Sec_YumiaoFafangEntity;

import org.xutils.DbManager;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.List;

/**
 * Created by Administrator on 2016/11/12 0012.
 */

public class Sec_YumiaofafangDao {
    public static boolean isSave;
    public static boolean isUpdate;
    private Context context;
    private final static DbManager manager= x.getDb(new MyApp().getDaoConfig());
    public final static String ACTION="SAVEORUPDATEFINISH";

    public Sec_YumiaofafangDao(Context context) {
        this.context = context;
    }
    //保存数据到数据库
    public  boolean saveInfo(Sec_YumiaoFafangEntity yumiaoffInfo){
        try {
            isSave=manager.saveBindingId(yumiaoffInfo);
            sendFinishBroad();
            return isSave;
        } catch (DbException e) {
            e.printStackTrace();
        }
        return false;
    }
    //查询数据
    public Sec_YumiaoFafangEntity getInfo(String farmer){
        Sec_YumiaoFafangEntity getInfo=null;
        try {
            getInfo= manager.findById(Sec_YumiaoFafangEntity.class,farmer);
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
        return getInfo;
    }
    //查询第一个数据
    public Sec_YumiaoFafangEntity getInfoFromDb(){
        Sec_YumiaoFafangEntity info=null;
        try {
            info= manager.findFirst(Sec_YumiaoFafangEntity.class);
        } catch (DbException e) {
            e.printStackTrace();
        }
        return info;
    }
    //查询所有的数据
    public void getAll(){
        try {
            List<Sec_YumiaoFafangEntity> list = manager.findAll(Sec_YumiaoFafangEntity.class);
            for (Sec_YumiaoFafangEntity info:list){
                Log.i("getAll",info.toString());
            }
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

    //更新数据
    public void upInfo(Sec_YumiaoFafangEntity yumiaoffInfo){

        try {
            manager.saveOrUpdate(yumiaoffInfo);
            isUpdate=true;
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //增加列数
    public void addColum(String newColum){
        try {
            manager.addColumn(Sec_YumiaoFafangEntity.class,newColum);
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //发送广播
    public void sendFinishBroad(){
        Intent intent=new Intent();
        intent.setAction(ACTION);
        context.sendBroadcast(intent);
    }
}
