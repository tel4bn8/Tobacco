package com.nss.tobacco.activitypreparation;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.HashMap;
import java.util.Map;

@ContentView(R.layout.activity_ymh_yumiao_sp_add)
public class YmhYumiaoSpAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;
    private boolean isSave = false;//是否保存

    @ViewInject(R.id.textView)
    TextView textViewtitle;
    @ViewInject(R.id.back_item)
    ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_edittext_gongmiaohu)
    private EditText etGongmiaohu;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_spinner_gongmiaoYear)
    private Spinner spGongmiaoYear;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_spinner_yanyeType)
    private Spinner spYanyeType;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_edittext_yumiaoNum)
    private EditText etYumiaoNum;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_edittext_yumiaoMianji)
    private EditText etYumiaoMianji;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_textview_yanjiyuan)
    private TextView tvYanjiyuan;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_textview_shenqingTime)
    private TextView tvShenqingTime;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_ymh_yumiao_sp_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        map = new HashMap<>();

        initView();
        initListener();

        setDate();

        mySpinner();

        setEditListener();
    }

    private void setEditListener() {
        etGongmiaohu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etGongmiaohu.getSelectionStart();
                editEnd = etGongmiaohu.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etGongmiaohu.setText(s);
                    etGongmiaohu.setSelection(tempSelection1);
                }
            }
        });
        etYumiaoNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etYumiaoNum.getSelectionStart();
                editEnd = etYumiaoNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etYumiaoNum.setText(s);
                    etYumiaoNum.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection1);
                }
            }
        });
        etYumiaoMianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etYumiaoMianji.getSelectionStart();
                editEnd = etYumiaoMianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etYumiaoMianji.setText(s);
                    etYumiaoMianji.setSelection(tempSelection1);
                }
            }
        });
    }

    private void mySpinner() {

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spGongmiaoYear.setAdapter(adapter2);
        String gongmianYear = spGongmiaoYear.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.yancaotype, R.layout.item_myspinner);
        spYanyeType.setAdapter(adapter3);
    }

    private void setDate() {

        String time = GetDate.lastDay();
        tvShenqingTime.setText(time);
        tvShenqingTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YmhYumiaoSpAddActivity.this);
                dialog.setDate(tvShenqingTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("育苗审批");

        //获取烟技员
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.frm_first_ymh_yumiao_sp_add:
                Toast.makeText(YmhYumiaoSpAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_yumiao_sp_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YmhYumiaoSpAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_yumiao_sp_add_btnback:
                myDialog();
                break;
            default:
                break;
        }
    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
