package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.Map;

@ContentView(R.layout.activity_yn_yantian_da_add)
public class YnYantianDaAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;

    @ViewInject(R.id.textView)
    private TextView textViewtitle;
    @ViewInject(R.id.back_item)
    private ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_yn_ytda_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_yannongName)
    private Spinner spYannongName;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_shiyongniandu)
    private Spinner spShiyongniandu;
    @ViewInject(R.id.frm_first_yn_ytda_add_edittext_mianji)
    private EditText etMianji;
    @ViewInject(R.id.frm_first_yn_ytda_add_textview_jingdu)
    private TextView tvJingdu;
    @ViewInject(R.id.frm_first_yn_ytda_add_textview_weidu)
    private TextView tvWeidu;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_soiltsrc)
    private Spinner spSoilsrc;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_soiltype)
    private Spinner spSoiltype;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_precrop)
    private Spinner spPrecrop;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_water)
    private Spinner spWater;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_dixing)
    private Spinner spDixing;
    @ViewInject(R.id.frm_first_yn_ytda_add_spinner_dilishuiping)
    private Spinner spDilishuiping;
    @ViewInject(R.id.frm_first_yn_ytda_add_textview_dengjiTime)
    private TextView tvDengjiTime;
    @ViewInject(R.id.frm_first_yn_ytda_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_yn_ytda_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_yn_ytda_add_btnback)
    private Button btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();

        initListener();

        setDate();

        mySpinner();

        setEditListener();
    }

    private void setEditListener() {
        etMianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etMianji.getSelectionStart();
                editEnd = etMianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etMianji.setText(s);
                    etMianji.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection2);
                }
            }
        });
    }

    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.yannongName, R.layout.item_myspinner);
        spYannongName.setAdapter(adapter1);
        String yannongName = spYannongName.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spShiyongniandu.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.dixing, R.layout.item_myspinner);
        spDixing.setAdapter(adapter3);

        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.tudilaiyuan, R.layout.item_myspinner);
        spSoilsrc.setAdapter(adapter4);

        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this, R.array.turangleixing, R.layout.item_myspinner);
        spSoiltype.setAdapter(adapter5);

        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this, R.array.qianchazuowu, R.layout.item_myspinner);
        spPrecrop.setAdapter(adapter6);

        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(this, R.array.paiguantiaojian, R.layout.item_myspinner);
        spWater.setAdapter(adapter7);

        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(this, R.array.dilishuiping, R.layout.item_myspinner);
        spDilishuiping.setAdapter(adapter8);
    }

    private void setDate() {
        String time = GetDate.lastDay();
        tvDengjiTime.setText(time);
        tvDengjiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YnYantianDaAddActivity.this);
                dialog.setDate(tvDengjiTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("烟田档案");

        //经纬度获取
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.frm_first_wg_yantian_gh_add:
                Toast.makeText(YnYantianDaAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_ytda_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YnYantianDaAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_ytda_add_btnback:
                myDialog();
                break;
            default:
                break;
        }
    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
