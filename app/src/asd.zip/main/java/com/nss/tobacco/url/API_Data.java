package com.nss.tobacco.url;

/**
 * Created by admin on 2016/11/17.
 */

public class API_Data {
    public static final String LOGIN = "http://192.168.1.103:8080/tobacco-app/yannong/login";
    public static final String APP_UPDATE = "http://192.168.1.103:8080/tobacco-app/init/app";
}
