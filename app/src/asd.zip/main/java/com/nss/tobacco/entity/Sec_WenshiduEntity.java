package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建温湿度管理的表
 */
@Table(name = "wenshiduguanli")
public class Sec_WenshiduEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "wendu")
    private String wendu;
    @Column(name = "shidu")
    private String shidu;
    @Column(name = "createtime")
    private String createtime;
    @Column(name = "detail")
    private String detail;

    public Sec_WenshiduEntity() {
    }

    public Sec_WenshiduEntity(String id, String wendu, String createtime, String shidu, String detail) {
        this.id = id;
        this.wendu = wendu;
        this.createtime = createtime;
        this.shidu = shidu;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWendu() {
        return wendu;
    }

    public void setWendu(String wendu) {
        this.wendu = wendu;
    }

    public String getShidu() {
        return shidu;
    }

    public void setShidu(String shidu) {
        this.shidu = shidu;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Sec_WenshiduEntity{" +
                "id='" + id + '\'' +
                ", wendu='" + wendu + '\'' +
                ", shidu='" + shidu + '\'' +
                ", createtime='" + createtime + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
