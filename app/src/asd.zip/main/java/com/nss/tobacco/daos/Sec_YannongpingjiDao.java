package com.nss.tobacco.daos;

/**
 * Created by Administrator on 2016/11/12 0012.
 */

public class Sec_YannongpingjiDao {
}
