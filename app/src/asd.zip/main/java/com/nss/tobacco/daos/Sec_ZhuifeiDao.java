package com.nss.tobacco.daos;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.nss.tobacco.MyApp;
import com.nss.tobacco.entity.Sec_XiaoduInfoEntity;
import com.nss.tobacco.entity.Sec_ZhuifeiEntity;

import org.xutils.DbManager;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.List;

/**
 * Created by Administrator on 2016/11/12 0012.
 */

public class Sec_ZhuifeiDao {
    public static boolean isSave;
    public static boolean isUpdate;
    private Context context;
    private final static DbManager manager= x.getDb(new MyApp().getDaoConfig());
    public final static String ACTION="SAVEORUPDATEFINISH";

    public Sec_ZhuifeiDao(Context context) {
        this.context = context;
    }
    //保存数据到数据库
    public  boolean saveInfo(Sec_ZhuifeiEntity zhuifeiInfo){
        try {
            isSave=manager.saveBindingId(zhuifeiInfo);
            sendFinishBroad();
            return isSave;
        } catch (DbException e) {
            e.printStackTrace();
        }
        return false;
    }
    //查询数据
    public Sec_ZhuifeiEntity getInfo(String farmer){
        Sec_ZhuifeiEntity getInfo=null;
        try {
            getInfo= manager.findById(Sec_ZhuifeiEntity.class,farmer);
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
        return getInfo;
    }
    //查询第一个数据
    public Sec_ZhuifeiEntity getInfoFromDb(){
        Sec_ZhuifeiEntity info=null;
        try {
            info= manager.findFirst(Sec_ZhuifeiEntity.class);
        } catch (DbException e) {
            e.printStackTrace();
        }
        return info;
    }
    //查询所有的数据
    public void getAll(){
        try {
            List<Sec_ZhuifeiEntity> list = manager.findAll(Sec_ZhuifeiEntity.class);
            for (Sec_ZhuifeiEntity info:list){
                Log.i("getAll",info.toString());
            }
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

    //更新数据
    public void upInfo(Sec_ZhuifeiEntity zhuifeiInfo){

        try {
            manager.saveOrUpdate(zhuifeiInfo);
            isUpdate=true;
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //增加列数
    public void addColum(String newColum){
        try {
            manager.addColumn(Sec_ZhuifeiEntity.class,newColum);
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //发送广播
    public void sendFinishBroad(){
        Intent intent=new Intent();
        intent.setAction(ACTION);
        context.sendBroadcast(intent);
    }
}
