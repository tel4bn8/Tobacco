package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建育苗发放的表
 */
@Table(name = "yanmiaofafang")
public class Sec_YumiaoFafangEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "type")
    private String type;
    @Column(name = "num")
    private String num;
    @Column(name = "createtime")
    private String createtime;
    @Column(name = "detail")
    private String detail;

    public Sec_YumiaoFafangEntity() {
    }

    public Sec_YumiaoFafangEntity(String id, String farmer, String type, String num, String createtime, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.type = type;
        this.num = num;
        this.createtime = createtime;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    @Override
    public String toString() {
        return "Sec_YumiaoFafangEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", type='" + type + '\'' +
                ", num='" + num + '\'' +
                ", createtime='" + createtime + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
