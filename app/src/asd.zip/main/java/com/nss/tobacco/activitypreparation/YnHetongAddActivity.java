package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.Map;

@ContentView(R.layout.activity_yn_hetong_add)
public class YnHetongAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;
    private boolean isSave = false;//是否保存

    @ViewInject(R.id.textView)
    TextView textViewtitle;
    @ViewInject(R.id.back_item)
    ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_yn_hetong_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_hetongID)
    private EditText etHetongID;
    @ViewInject(R.id.frm_first_yn_htgl_add_spinner_qianyueniandu)
    private Spinner spQianyueniandu;
    @ViewInject(R.id.frm_first_yn_htgl_add_spinner_yannongName)
    private Spinner spYannongName;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_caoqianmianji)
    private EditText etCaoqianmianji;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_caoqianNum)
    private EditText etcaoqianNum;
    @ViewInject(R.id.frm_first_yn_htgl_add_textview_caoqianTime)
    private TextView tvCaoqianTime;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_jiaoxiaomianji)
    private EditText etJiaoxiaonianji;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_jiaoxiaoNum)
    private EditText etJiaoxiaoNum;
    @ViewInject(R.id.frm_first_yn_htgl_add_textview_qianyueTime)
    private TextView tvQianyueTime;
    @ViewInject(R.id.frm_first_yn_htgl_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_yn_htgl_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_yn_htgl_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
        initListener();

        setDate();

        mySpinner();

        setEditListener();

    }

    private void setEditListener() {
        etHetongID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etHetongID.getSelectionStart();
                editEnd = etHetongID.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etHetongID.setText(s);
                    etHetongID.setSelection(tempSelection2);
                }
            }
        });
        etCaoqianmianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etCaoqianmianji.getSelectionStart();
                editEnd = etCaoqianmianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etCaoqianmianji.setText(s);
                    etCaoqianmianji.setSelection(tempSelection2);
                }
            }
        });
        etcaoqianNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etcaoqianNum.getSelectionStart();
                editEnd = etcaoqianNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etcaoqianNum.setText(s);
                    etcaoqianNum.setSelection(tempSelection2);
                }
            }
        });
        etJiaoxiaonianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etJiaoxiaonianji.getSelectionStart();
                editEnd = etJiaoxiaonianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etJiaoxiaonianji.setText(s);
                    etJiaoxiaonianji.setSelection(tempSelection2);
                }
            }
        });
        etJiaoxiaoNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etJiaoxiaoNum.getSelectionStart();
                editEnd = etJiaoxiaoNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etJiaoxiaoNum.setText(s);
                    etJiaoxiaoNum.setSelection(tempSelection2);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection2);
                }
            }
        });
    }

    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spQianyueniandu.setAdapter(adapter1);
        String village = spQianyueniandu.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.yannongName, R.layout.item_myspinner);
        spYannongName.setAdapter(adapter2);
    }

    private void setDate() {

        String time1 = GetDate.lastDay();
        tvCaoqianTime.setText(time1);
        tvCaoqianTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YnHetongAddActivity.this);
                dialog.setDate(tvCaoqianTime);
            }
        });

        String time2 = GetDate.lastDay();
        tvQianyueTime.setText(time2);
        tvQianyueTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YnHetongAddActivity.this);
                dialog.setDate(tvQianyueTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("合同管理");
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.frm_first_yn_hetong_add:
                Toast.makeText(YnHetongAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_htgl_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YnHetongAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_htgl_add_btnback:
                Toast.makeText(YnHetongAddActivity.this, "返回", Toast.LENGTH_SHORT).show();
                myDialog();
                break;
            default:
                break;
        }
    }

    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
