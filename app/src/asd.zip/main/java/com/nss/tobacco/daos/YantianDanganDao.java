package com.nss.tobacco.daos;

/**
 * YantianDanganDao
 */

public class YantianDanganDao {
}
