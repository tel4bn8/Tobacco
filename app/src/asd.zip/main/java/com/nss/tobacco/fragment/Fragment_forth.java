package com.nss.tobacco.fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.activity.AboutUs;
import com.nss.tobacco.activity.HelpDoc;
import com.nss.tobacco.activity.MainActivity;
import com.nss.tobacco.activity.SetYearActivity;
import com.nss.tobacco.entity.UpdateInfo;
import com.nss.tobacco.utils.UpdateInfoService;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.io.File;

/**
 * Created by Administrator on 2016/10/25 0025.
 */

public class Fragment_forth extends Fragment implements View.OnClickListener{

    private TextView forthAdminName;

    private LinearLayout linearLayout1, linearLayout2, linearLayout3, linearLayout4, linearLayout5, linearLayout6;
    private Button button;

    private String realname;

    //app更新
    private UpdateInfo updateInfo;
    private ProgressDialog progressDialog;
    Context context;
    private Handler handler;
    private static final String BASE_PATH = Environment.getExternalStorageDirectory().getPath() + File.separator;

    public Fragment_forth() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //获取烟技员姓名
        realname = ((MainActivity)getActivity()).getRealname();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frm_forth, container, false);

        initView(view);

        initListener();

        return view;
    }

    private void initListener() {
        linearLayout1.setOnClickListener(this);
        linearLayout2.setOnClickListener(this);
        linearLayout3.setOnClickListener(this);
        linearLayout4.setOnClickListener(this);
        linearLayout5.setOnClickListener(this);
        linearLayout6.setOnClickListener(this);

        button.setOnClickListener(this);
    }

    private void initView(View view) {

        //显示管理员姓名
        forthAdminName = (TextView) view.findViewById(R.id.frm_forth_tv_adminName);
        forthAdminName.setText(realname);

        linearLayout1 = (LinearLayout) view.findViewById(R.id.frm_forth_ndsz);
        linearLayout2 = (LinearLayout) view.findViewById(R.id.frm_forth_sjql);
        linearLayout3 = (LinearLayout) view.findViewById(R.id.frm_forth_bzwd);
        linearLayout4 = (LinearLayout) view.findViewById(R.id.frm_forth_mmxg);
        linearLayout5 = (LinearLayout) view.findViewById(R.id.frm_forth_rjsj);
        linearLayout6 = (LinearLayout) view.findViewById(R.id.frm_forth_gyxt);

        button = (Button) view.findViewById(R.id.frm_forth_btn_out);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()){
            case R.id.frm_forth_ndsz://年度设置
                intent.setClass(getContext(), SetYearActivity.class);
                startActivity(intent);
                break;
            case R.id.frm_forth_sjql://数据清理

                Toast.makeText(getContext(), "数据已清理",Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_forth_bzwd://帮助文档
                intent.setClass(getContext(), HelpDoc.class);
                startActivity(intent);
                break;
            case R.id.frm_forth_mmxg://密码修改
                Toast.makeText(getContext(), "后台测试",Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_forth_rjsj://软件升级

                Toast.makeText(getContext(), "您的软件已是最新版本",Toast.LENGTH_SHORT).show();
                /*new Thread() {
                    @Override
                    public void run() {

                        try {
                            UpdateInfoService updateInfoService = new UpdateInfoService(getContext());
                            updateInfo = updateInfoService.getUpdataInfo();

                            handler.sendEmptyMessage(0);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();

                 handler = new Handler() {
                    @Override
                    public void handleMessage(Message msg) {
                        super.handleMessage(msg);
                        if (isNeedUpdate(context)){
                            showUpdateDialog();
                        }else {
                            Toast.makeText(getContext(), "已经是最新版本", Toast.LENGTH_SHORT).show();
                        }
                    }
                };*/
                break;
            case R.id.frm_forth_gyxt://关于系统
                intent.setClass(getContext(), AboutUs.class);
                startActivity(intent);
                break;
            case R.id.frm_forth_btn_out://退出

                break;
        }
    }



    public void showUpdateDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setIcon(R.drawable.ic_help_normal);
        builder.setTitle("请更新软件至版本" + updateInfo.getVersion());
        builder.setMessage(updateInfo.getCreatetime());
        builder.setCancelable(false);

        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
                    downFile(updateInfo.getPath(),BASE_PATH);
                }else {
                    Toast.makeText(getContext(), "SD卡不可用，请插入SD卡", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();

    }

    //判断是否需要更新
    public boolean isNeedUpdate(Context context) {

        String vs = updateInfo.getVersion();
        Log.i("update", vs);
        if (vs.equals(getVersion(context))) {
            return false;
        } else {
            return true;
        }
    }

    //获取当前版本名
    private String getVersion(Context context) {

        try {
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);

            return packageInfo.versionName;//返回当前版本号
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();

            return "未知版本号";
        }
    }

    //下载app
    void downFile(final String url, final String path) {

        new Thread() {
            @Override
            public void run() {

                RequestParams requestParams = new RequestParams(url);
                requestParams.setSaveFilePath(path);
                x.http().get(requestParams, new Callback.ProgressCallback<File>() {

                    @Override
                    public void onWaiting() {
                    }

                    @Override
                    public void onStarted() {
                    }


                    @Override
                    public void onLoading(long total, long current, boolean isDownloading) {

                        //进度条
                        progressDialog = new ProgressDialog(getContext());
                        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                        progressDialog.setTitle("正在下载");
                        progressDialog.setMessage("请稍后");
                        progressDialog.show();
                        progressDialog.setMax((int) total);
                        progressDialog.setProgress((int) current);

                    }

                    @Override
                    public void onSuccess(File result) {
                        Toast.makeText(getContext(), "下载成功", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onError(Throwable ex, boolean isOnCallback) {
                        ex.printStackTrace();
                        Toast.makeText(getContext(), "下载失败，请检查网络和SD卡", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(Callback.CancelledException cex) {

                    }

                    @Override
                    public void onFinished() {

                    }
                });
            }
        }.start();

    }
}
