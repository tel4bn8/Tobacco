package com.nss.tobacco.entity;

import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建打顶抑牙的表
 */
@Table(name = "dadingyiya")
public class Sec_DadingEntity {
}
