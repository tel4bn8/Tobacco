package com.nss.tobacco.activitymanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CaremaAdapter;
import com.nss.tobacco.utils.CommonUtil;
import com.nss.tobacco.utils.Constants;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;
import com.nss.tobacco.utils.MyCallBack;
import com.nss.tobacco.utils.PhotoUtil;
import com.nss.tobacco.utils.XUtil;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ContentView(R.layout.activity_add__bingchonghai)
public class Add_BingchongFangzhiActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;

    private Map<String,Object> map;
    private Bitmap bitmap;
    private String str;

    //拍照
    private Context context;
    private String location2;
    private static final int CRAEMA_REQUEST_CODE = 0; //拍照请求码

    private boolean candelete = false; //是否可以删除照片
    private String defaultPhotoAddress = null; //拍照生成默认照片的绝对路径
    private String photoFolderAddress = null; //存放照片的文件夹

    private List<String> listPhotoNames = null;
    private CaremaAdapter cadapter = null;
    private int screenWidth = 0; //屏幕宽度

    @ViewInject(R.id.textView)
    TextView textView;
    @ViewInject(R.id.shijian_text)
    TextView dateText1;
    @ViewInject(R.id.back_item)
    ImageView back_img;

    @ViewInject(R.id.second_ym_bcfz_imageview)
    ImageView imageViewPhoto;
    @ViewInject(R.id.second_ym_bcfz_gridView)
    GridView  photoGridView;//拍摄图片的位置


    @ViewInject(R.id.spinner_zhongzhihu)
    Spinner name;
    @ViewInject(R.id.yaowuming_edit)
    EditText yaoming;
    @ViewInject(R.id.fangzhi_edit)
    EditText fangzhifangshi;
    @ViewInject(R.id.nongdu_edit)
    EditText nongdu;
    @ViewInject(R.id.spinner_leixing)
    Spinner leixing;
    @ViewInject(R.id.fabinglv_edit)
    EditText fabinglv;
    @ViewInject(R.id.fabingmianji_edit)
    EditText mianji;
    @ViewInject(R.id.yugu_edit)
    EditText yugu;
    @ViewInject(R.id.shijian_text)
    TextView shijian;
    @ViewInject(R.id.biaozhun_pic)
    ImageView biaozhun;
    @ViewInject(R.id.beizhu_edit)
    EditText beizhu;
    @ViewInject(R.id.btn_save)
    Button save;
    @ViewInject(R.id.btn_back)
    Button back_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        map=new HashMap<>();
        initView();
        mySpinner();
        initCarema();
        setListener();
    }

    //初始化相机
    private void initCarema() {
        //初始化相机拍摄图片路径
        defaultPhotoAddress=CommonUtil.getSDPath()+ File.separator+"default.jpg";
        //获取屏幕的分辨率
        DisplayMetrics dm=new DisplayMetrics();
        //获得窗口属性
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        screenWidth=dm.widthPixels;
        //是否可删除图片
        candelete=getIntent().getBooleanExtra("candelete",true);

        //获取文件夹
        if(getIntent().getStringExtra("folderName")==null){
            photoFolderAddress=CommonUtil.getSDPath()+File.separator+"bingchongfangzhi";
        }else{
            photoFolderAddress=getIntent().getStringExtra("folderName");
        }
    }

    private void initView() {
        textView.setText("病虫防治");
    }

    private void setListener() {
        back_img.setOnClickListener(this);
        imageViewPhoto.setOnClickListener(this);
        save.setOnClickListener(this);
        back_btn.setOnClickListener(this);
        getMianjiEditListener();
        setDate();
    }

    private void setDate() {
        //时间选择
        dateText1.setText(GetDate.lastDay());
        dateText1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_BingchongFangzhiActivity.this);
                dialog.setDate(dateText1);
            }
        });
    }

    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.age, R.layout.item_myspinner);
        name.setAdapter(adapter1);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.bingchongleixing, R.layout.item_myspinner);
        leixing.setAdapter(adapter2);
    }
  //onClick事件
    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.second_ym_bcfz_imageview:
                //验证SD卡是否可用
                if(CommonUtil.getSDPath()==null){
                    Toast.makeText(Add_BingchongFangzhiActivity.this, "请安装SD卡", Toast.LENGTH_SHORT).show();
                    return;
                }
                //验证图片是否超出图片数量
                if(listPhotoNames!=null&&listPhotoNames.size()>= Constants.MAX_PHOTO_SIZE)
                {
                    Toast.makeText(Add_BingchongFangzhiActivity.this, "最多只允许拍摄"+Constants.MAX_PHOTO_SIZE+"张照片", Toast.LENGTH_SHORT).show();
                    return;
                }

                //调用系统拍照
                intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(defaultPhotoAddress)));
                startActivityForResult(intent,CRAEMA_REQUEST_CODE);
                break;
            case R.id.btn_save:
                //getData();
                //uploadfile();
                //post();
                break;
            case R.id.btn_back:
              myDialog();
                break;
            default:
                break;
        }
    }
    private void post() {
        String url="http://192.168.0.108:8080/tobacco-app/yannong/queryAllYannongBytech";
        Map<String,Object> map=new HashMap<>();
        map.put("username", "admin");
        map.put("password", "123");
        XUtil.Post(url, map, new MyCallBack<String>(){
            @Override
            public void onSuccess(String result) {
                super.onSuccess(result);
                Log.e("result", result);
            }
            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                super.onError(ex, isOnCallback);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            switch (requestCode){
                case CRAEMA_REQUEST_CODE:

                    break;

            }
        }
    }

    private void uploadfile() {
        //图片上传地址
        String url="http://192.168.0.108:8080/tobacco-app/yantianguanli/addBingchongfangzhi";
        //传入自己的相应参数map
        XUtil.UpLoadFile(url, map, new MyCallBack<String>(){
            @Override
            public void onSuccess(String result) {
                super.onSuccess(result);
            }
            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                super.onError(ex, isOnCallback);
            }
        });
    }
    public void getMianjiEditListener(){
        mianji.addTextChangedListener(new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            temp = s;
        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
        @Override
        public void afterTextChanged(Editable s) {
            map.put("area",s);
            editStart = mianji.getSelectionStart();
            editEnd = mianji.getSelectionEnd();
            if (temp.length() > 10) {//限制长度
                Toast.makeText(Add_BingchongFangzhiActivity.this,
                        "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                        .show();
                s.delete(editStart - 1, editEnd);
                int tempSelection = editStart;
                mianji.setText(s);
                mianji.setSelection(tempSelection);
            }
        }
    });
    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(Add_BingchongFangzhiActivity.this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
   /* //从网络获取数据
    private void getData() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String json = "http://192.168.0.108:8080/tobacco-app/yannong/queryAllYannongBytech";
                String jsonString2 = HttpUtils.getJsonContent(json);//从网络获取数据
                List<ZhongzhihuInfoBean> list = GsonTools.getPersons(jsonString2,ZhongzhihuInfoBean.class);//解析json数据
                Log.i("Tag", "-------------"+list.toString());

            }
        });
        thread.start();

    }*/
   /* @SuppressLint("SdCardPath")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            String sdStatus = Environment.getExternalStorageState();
            if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
                Log.i("TestFile",
                        "SD card is not avaiable/writeable right now.");
                return;
            }
            new DateFormat();
            String name = DateFormat.format("yyyyMMdd_hhmmss", Calendar.getInstance(Locale.CHINA)) + ".jpg";
            Toast.makeText(this, name, Toast.LENGTH_LONG).show();
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");// 获取相机返回的数据，并转换为Bitmap图片格式

            FileOutputStream b = null;
            File file = new File("/sdcard/Image/");
            file.mkdirs();// 创建文件夹
            String fileName = "/sdcard/Image/"+name;
            try {
                b = new FileOutputStream(fileName);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// 把数据写入文件
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    b.flush();
                    b.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try
            {
                photo1.setImageBitmap(bitmap);// 将图片显示在ImageView里
            }catch(Exception e)
            {
                Log.e("error", e.getMessage());
            }

        }
    }*/

}
