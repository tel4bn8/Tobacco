package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建移栽管理的表
 */
@Table(name = "yizai")
public class Sec_YizaiEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "type")
    private String type;
    @Column(name = "area")
    private String area;
    @Column(name = "rowdis")
    private String rowdis;
    @Column(name = "betwdis")
    private String betwdis;
    @Column(name = "mo")
    private String mo;
    @Column(name = "way")
    private String way;
    @Column(name = "bingchong")
    private String bingchong;
    @Column(name = "alive")
    private String alive;
    @Column(name = "detail")
    private String detail;

    public Sec_YizaiEntity() {
    }

    public Sec_YizaiEntity(String id, String farmer, String type, String area, String rowdis, String betwdis, String mo, String way, String bingchong, String alive, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.type = type;
        this.area = area;
        this.rowdis = rowdis;
        this.betwdis = betwdis;
        this.mo = mo;
        this.way = way;
        this.bingchong = bingchong;
        this.alive = alive;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAlive() {
        return alive;
    }

    public void setAlive(String alive) {
        this.alive = alive;
    }

    public String getBingchong() {
        return bingchong;
    }

    public void setBingchong(String bingchong) {
        this.bingchong = bingchong;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getMo() {
        return mo;
    }

    public void setMo(String mo) {
        this.mo = mo;
    }

    public String getBetwdis() {
        return betwdis;
    }

    public void setBetwdis(String betwdis) {
        this.betwdis = betwdis;
    }

    public String getRowdis() {
        return rowdis;
    }

    public void setRowdis(String rowdis) {
        this.rowdis = rowdis;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    @Override
    public String toString() {
        return "Sec_YizaiEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", type='" + type + '\'' +
                ", area='" + area + '\'' +
                ", rowdis='" + rowdis + '\'' +
                ", betwdis='" + betwdis + '\'' +
                ", mo='" + mo + '\'' +
                ", way='" + way + '\'' +
                ", bingchong='" + bingchong + '\'' +
                ", alive='" + alive + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
