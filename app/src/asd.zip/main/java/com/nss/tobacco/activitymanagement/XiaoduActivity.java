package com.nss.tobacco.activitymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CommonAdapter;
import com.nss.tobacco.adapter.ViewHolder;
import com.nss.tobacco.daos.DBManager;
import com.nss.tobacco.daos.WirelessQA;
import com.nss.tobacco.entity.Sec_XiaoduInfoEntity;
import com.nss.tobacco.utils.DividerItemDecoration;
import com.nss.tobacco.utils.IdUtil;
import com.nss.tobacco.utils.MyCallBack;
import com.nss.tobacco.utils.XUtil;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ContentView(R.layout.activity_xiaodu)
public class XiaoduActivity extends AppCompatActivity implements View.OnClickListener {
    private List<String> mDatas,mDatas2;
    private CommonAdapter<String>  adapter,adapter2;
    private DBManager dbManager;
    private String[] words;
    private String farmername;
    private Map<String,Object> map;
    private String state;

    @ViewInject(R.id.textView_item)
    TextView textView;
    @ViewInject(R.id.back_item)
    ImageView back_img;
    @ViewInject(R.id.add_item)
    TextView add_text;
    @ViewInject(R.id.up_item)
    TextView upload;
    @ViewInject(R.id.year_item)
    Spinner year_spinner;
    @ViewInject(R.id.searchbox)
    EditText search_edit;
    @ViewInject(R.id.search_item)
    Button search_btn;
    @ViewInject(R.id.swipe_refresh_widget)
    SwipeRefreshLayout mSwipeRefreshWidget;
    @ViewInject(R.id.id_recyclerview)
    RecyclerView mRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        dbManager = new DBManager(this);
        initView();
        initData();
        myRecyclerView();
        init();
        //监听事件
        setLitsener();
    }
    private void init() {
        //设置圈内的颜色
        mSwipeRefreshWidget.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);
        //设置下拉刷新监听
        mSwipeRefreshWidget.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        initData();
                        myRecyclerView();
                        adapter.notifyDataSetChanged();
                        //停止刷新动画
                        mSwipeRefreshWidget.setRefreshing(false);
                    }
                }, 3000);
            }
        });

    }
    private void initData() {
        mDatas = new ArrayList<String>();
        ArrayList<Sec_XiaoduInfoEntity> infoList = new ArrayList<Sec_XiaoduInfoEntity>();
        infoList = dbManager.searchAllData();
        for (Sec_XiaoduInfoEntity info : infoList) {
            state = info.state;
            map=new HashMap<>();
            String id = IdUtil.getId();
            map.put("id",id);
            map.put("farmer",info.farmer);
            map.put("createtime",info.createtime);
            map.put("sheshi",info.sheshi);
            map.put("yaopin",info.yaopin);
            map.put("detail",info.detail);
            Log.i("result","--------ppppppppppppp"+ map.toString());
            mDatas.add(0,info.createtime+" "+info.farmer);
            Log.i("aaa",  "cccccccccccccccccc"+info.farmer+info.createtime+info.sheshi+info.yaopin+info.detail+info.state);
        }
    }

    private void initView() {
        textView.setText("消毒");
        mySpinner();
    }
      private void myRecyclerView() {
          mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
          adapter = new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview, mDatas) {
              @Override
              public void convert(ViewHolder holder, String s) {
                  holder.setText(R.id.id_num,s);
              }
              @Override
              public void onBindViewHolder(final ViewHolder holder, final int position) {
                  super.onBindViewHolder(holder, position);
                  holder.setOnClickListener(R.id.id_num, new View.OnClickListener() {
                      @Override
                      public void onClick(View v) {
                          mDatas.get(position);
                          Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mDatas.get(position));
                          words = mDatas.get(position).split(" ");
                          farmername = words[1];
                          Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+farmername);
                          String time = words[0];
                          Toast.makeText(getApplicationContext(),"aaaaa"+position,Toast.LENGTH_LONG).show();
                          searchByname();
                      }
                  });
              }
          };
          mRecyclerView.setAdapter(adapter);
          //分割线
          mRecyclerView.addItemDecoration(new DividerItemDecoration(this,
                  DividerItemDecoration.VERTICAL_LIST));
    }
    //查询数据库传递详细信息跳转页面
    private void searchByname() {
        ArrayList<Sec_XiaoduInfoEntity> infoList = new ArrayList();
        infoList = dbManager.searchData(farmername);
        String result = null;
        for (Sec_XiaoduInfoEntity info : infoList){
            result = info.farmer + " " + info.createtime
                    + " " + info.yaopin + " " + info.sheshi+ " " +info.detail;
        }
        Log.i(WirelessQA.TAG, "-----------------ddddd"+result);
        startSec_msg_XiaoduActivity("searchResult", result);
    }

    private void startSec_msg_XiaoduActivity(String intentName, String intentValue) {
        Intent intent = new Intent(this, Sec_msg_XiaoduActivity.class);
        intent.putExtra(intentName, intentValue);
        startActivity(intent);
    }
    private void setLitsener(){
        back_img.setOnClickListener(this);
        add_text.setOnClickListener(this);
        upload.setOnClickListener(this);
        search_btn.setOnClickListener(this);
    }
    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.year_item, R.layout.item_myspinner);
        Spinner spinner = (Spinner) findViewById(R.id.year_item);
        spinner.setAdapter(adapter);
    }
    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.add_item:
                intent.setClass(this, Add_XiaoduActivity.class);
                startActivity(intent);
                break;
            case R.id.up_item:
                dbManager.clearData();
                adapter.notifyDataSetChanged();
                //post();
                Toast.makeText(this,"已经上传成功",Toast.LENGTH_LONG).show();
                //判断state状态值
                /*updateState();*/
                break;
            case R.id.year_item:

                break;
            //搜索按钮
            case R.id.search_item:
                searchMyRecy();
                break;
            default:
                break;
        }
    }
    private void updateState() {
        String state = "1";
        dbManager.updateLieData("state",state);
    }
    //上传数据
    private void post() {
        String url="http://192.168.1.103:8080/tobacco-app/yumiao/xiaodu";
        XUtil.Post(url, map, new MyCallBack<String>(){
            @Override
            public void onSuccess(String result) {
                super.onSuccess(result);
                Log.i("result", "--------www"+result);
            }
            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                super.onError(ex, isOnCallback);
                Log.i("result", "--------www"+"失败");
            }
        });
    }
    //搜索功能
    private void searchMyRecy() {
        search_edit = (EditText) findViewById(R.id.searchbox);
        String str = search_edit.getText().toString();
        Log.i("aaa",  "cccccccccccccccccc2"+str);
        ArrayList<Sec_XiaoduInfoEntity> infoList = new ArrayList<Sec_XiaoduInfoEntity>();
        infoList = dbManager.searchAllData();
        mDatas2 = new ArrayList<String>();
        for(Sec_XiaoduInfoEntity info2 : infoList){
            if (info2.farmer.equals(str)){
                mDatas2.add(info2.createtime+" "+info2.farmer);
                Log.i("aaa", "cccccccccccccccccc2"+info2.createtime+info2.sheshi+info2.yaopin+info2.yaopin);
            }
        }
        adapter2 = new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview, mDatas2) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.id_num,s);
            }
            @Override
            public void onBindViewHolder(final ViewHolder holder, final int position) {
                super.onBindViewHolder(holder, position);
                holder.setOnClickListener(R.id.id_num, new View.OnClickListener() {
                    @Override
                    public void onClick(View v){
                        mDatas2.get(position);
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mDatas2.get(position));
                        words = mDatas2.get(position).split(" ");
                        farmername = words[1];
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+farmername);
                        String time = words[0];
                        Toast.makeText(getApplicationContext(),"aaaaa"+position,Toast.LENGTH_LONG).show();
                        searchByname();
                    }
                });
            }
        };
        mRecyclerView.setAdapter(adapter2);
    }
}
