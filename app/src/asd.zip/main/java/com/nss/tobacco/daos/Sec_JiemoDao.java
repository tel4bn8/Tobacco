package com.nss.tobacco.daos;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.nss.tobacco.MyApp;
import com.nss.tobacco.entity.Sec_JiemoEntity;

import org.xutils.DbManager;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.List;

/**
 * Created by Administrator on 2016/11/12 0012.
 */

public class Sec_JiemoDao {
    public static boolean isSave;
    public static boolean isUpdate;
    private Context context;
    private final static DbManager manager= x.getDb(new MyApp().getDaoConfig());
    public final static String ACTION="SAVEORUPDATEFINISH";

    public Sec_JiemoDao(Context context) {
        this.context = context;
    }
    //保存数据到数据库
    public  boolean saveInfo(Sec_JiemoEntity jiemoInfo){
        try {
            isSave=manager.saveBindingId(jiemoInfo);
            sendFinishBroad();
            return isSave;
        } catch (DbException e) {
            e.printStackTrace();
        }
        return false;
    }
    //查询数据
    public Sec_JiemoEntity getInfo(String farmer){
        Sec_JiemoEntity getInfo=null;
        try {
            getInfo= manager.findById(Sec_JiemoEntity.class,farmer);
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
        return getInfo;
    }
    //查询第一个数据
    public Sec_JiemoEntity getInfoFromDb(){
        Sec_JiemoEntity info=null;
        try {
            info= manager.findFirst(Sec_JiemoEntity.class);
        } catch (DbException e) {
            e.printStackTrace();
        }
        return info;
    }
    //查询所有的数据
    public void getAll(){
        try {
            List<Sec_JiemoEntity> list = manager.findAll(Sec_JiemoEntity.class);
            for (Sec_JiemoEntity info:list){
                Log.i("getAll",info.toString());
            }
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

    //更新数据
    public void upInfo(Sec_JiemoEntity jiemoInfo){

        try {
            manager.saveOrUpdate(jiemoInfo);
            isUpdate=true;
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //增加列数
    public void addColum(String newColum){
        try {
            manager.addColumn(Sec_JiemoEntity.class,newColum);
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //发送广播
    public void sendFinishBroad(){
        Intent intent=new Intent();
        intent.setAction(ACTION);
        context.sendBroadcast(intent);
    }
}
