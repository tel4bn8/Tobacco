package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建苗期管理的表
 */
//创建表
@Table(name = "miaoqiguanli")
public class Sec_MiaoqiguanliEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "gongchangid")
    private String gongchangid;
    @Column(name = "bozhongtime")
    private String bozhongtime;
    @Column(name = "chumiaotime")
    private String chumiaotime;
    @Column(name = "jiandingmiaotime")
    private String jiandingmiaotime;
    @Column(name = "jianyetime")
    private String jianyetime;
    @Column(name = "lianmiaotime")
    private String lianmiaotime;
    @Column(name = "gongmiaotime")
    private String gongmiaotime;
    @Column(name = "strong")
    private String strong;
    @Column(name = "detail")
    private String detail;

    public Sec_MiaoqiguanliEntity() {
    }

    public Sec_MiaoqiguanliEntity(String id, String farmer, String gongchangid, String bozhongtime, String chumiaotime, String jiandingmiaotime, String jianyetime, String lianmiaotime, String gongmiaotime, String strong, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.gongchangid = gongchangid;
        this.bozhongtime = bozhongtime;
        this.chumiaotime = chumiaotime;
        this.jiandingmiaotime = jiandingmiaotime;
        this.jianyetime = jianyetime;
        this.lianmiaotime = lianmiaotime;
        this.gongmiaotime = gongmiaotime;
        this.strong = strong;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getGongchangid() {
        return gongchangid;
    }

    public void setGongchangid(String gongchangid) {
        this.gongchangid = gongchangid;
    }

    public String getBozhongtime() {
        return bozhongtime;
    }

    public void setBozhongtime(String bozhongtime) {
        this.bozhongtime = bozhongtime;
    }

    public String getChumiaotime() {
        return chumiaotime;
    }

    public void setChumiaotime(String chumiaotime) {
        this.chumiaotime = chumiaotime;
    }

    public String getJiandingmiaotime() {
        return jiandingmiaotime;
    }

    public void setJiandingmiaotime(String jiandingmiaotime) {
        this.jiandingmiaotime = jiandingmiaotime;
    }

    public String getJianyetime() {
        return jianyetime;
    }

    public void setJianyetime(String jianyetime) {
        this.jianyetime = jianyetime;
    }

    public String getLianmiaotime() {
        return lianmiaotime;
    }

    public void setLianmiaotime(String lianmiaotime) {
        this.lianmiaotime = lianmiaotime;
    }

    public String getGongmiaotime() {
        return gongmiaotime;
    }

    public void setGongmiaotime(String gongmiaotime) {
        this.gongmiaotime = gongmiaotime;
    }

    public String getStrong() {
        return strong;
    }

    public void setStrong(String strong) {
        this.strong = strong;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Sec_MiaoqiguanliEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", gongchangid='" + gongchangid + '\'' +
                ", bozhongtime='" + bozhongtime + '\'' +
                ", chumiaotime='" + chumiaotime + '\'' +
                ", jiandingmiaotime='" + jiandingmiaotime + '\'' +
                ", jianyetime='" + jianyetime + '\'' +
                ", lianmiaotime='" + lianmiaotime + '\'' +
                ", gongmiaotime='" + gongmiaotime + '\'' +
                ", strong='" + strong + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
