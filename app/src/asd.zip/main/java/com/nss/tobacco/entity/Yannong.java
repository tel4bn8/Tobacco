package com.nss.tobacco.entity;

/**
 * Created by admin on 2016/11/5.
 */

public class Yannong {

}
