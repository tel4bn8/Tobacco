package com.nss.tobacco.entity;

/**
 * Created by Administrator on 2016/11/8 0008.
 */

public class Sec_ChanliangyuceEntity {
}
