package com.nss.tobacco.entity;

/**
 * Created by admin on 2016/11/7.
 */

public class YumiaoGongchang {
}
