package com.nss.tobacco.daos;

/**
 * Created by admin on 2016/11/2.
 */

public class JichuSheshiDao {
}
