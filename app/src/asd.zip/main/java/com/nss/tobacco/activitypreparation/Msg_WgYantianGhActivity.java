package com.nss.tobacco.activitypreparation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.nss.tobacco.R;
import com.nss.tobacco.daos.WirelessQA;

public class Msg_WgYantianGhActivity extends AppCompatActivity {

    private String result = null;

    private TextView tvTitle, tvVillage, tvYear, tvArea, tvlng, tvlat, tvdixing, tvtuzhi,
            tvsoil, tvfeili, tvmoditime, tvtechnician, tvdetail;
    private Button btnback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg__wg_yantian_gh);

        initView();
        initData();
        setListener();
    }

    private void setListener() {
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initData() {
        Bundle extras = getIntent().getExtras();
        result = extras.getString("searchResult");
        Log.i(WirelessQA.TAG, "-----------------eeeeeeeeeeeeee"+result);
        String[] msg = result.split(" ");
        if(msg.length==4){
            tvVillage.setText(msg[0]);
            Log.i(WirelessQA.TAG, "-----------------fffffffffffffff"+msg[0]);
            tvYear.setText(msg[1]);
            tvArea.setText(msg[2]);
            tvlng.setText(msg[3]);
            tvlat.setText(msg[4]);
            tvdixing.setText(msg[5]);
            tvtuzhi.setText(msg[6]);
            tvsoil.setText(msg[7]);
            tvfeili.setText(msg[8]);
            tvmoditime.setText(msg[9]);
            tvtechnician.setText(msg[10]);

        }else{
            tvVillage.setText(msg[0]);
            Log.i(WirelessQA.TAG, "-----------------fffffffffffffff"+msg[0]);
            tvYear.setText(msg[1]);
            tvArea.setText(msg[2]);
            tvlng.setText(msg[3]);
            tvlat.setText(msg[4]);
            tvdixing.setText(msg[5]);
            tvtuzhi.setText(msg[6]);
            tvsoil.setText(msg[7]);
            tvfeili.setText(msg[8]);
            tvmoditime.setText(msg[9]);
            tvtechnician.setText(msg[10]);
            tvdetail.setText(msg[11]);
        }
    }

    private void initView() {
        tvTitle = (TextView) findViewById(R.id.textView);
        tvTitle.setText("烟田规划");

        tvVillage = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_village);
        tvYear = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_guhuaniandu);
        tvArea = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_mianji);
        tvlng = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_jingdu);
        tvlat = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_weidu);
        tvdixing = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_dixing);
        tvtuzhi = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_tuzhileixing);
        tvsoil = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_turangfeili);
        tvfeili = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_turangleixing);
        tvmoditime = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_modiTime);
        tvtechnician = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_yanjiyuan);
        tvdetail = (TextView) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_textview_beizhu);

        btnback = (Button) findViewById(R.id.frm_first_msg_wg_yantian_gh_add_btnback);
    }
}
