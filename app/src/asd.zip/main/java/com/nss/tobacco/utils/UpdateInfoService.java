package com.nss.tobacco.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;
import com.nss.tobacco.entity.UpdateInfo;
import com.nss.tobacco.url.API_Data;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

/**
 *
 */

public class UpdateInfoService {

    private UpdateInfo update;
    Context context;

    public UpdateInfoService(Context context) {
        this.context = context;
    }



    public UpdateInfo getUpdataInfo() {
        RequestParams params = new RequestParams(API_Data.APP_UPDATE);

        x.http().get(params, new Callback.CommonCallback<String>() {
            @Override
            public void onSuccess(String result) {
                Log.i("ffff", result);
                Gson gson = new Gson();
                update = gson.fromJson(result, UpdateInfo.class);
                String a = update.getVersion();
                Log.i("ffff", a);
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback) {

            }

            @Override
            public void onCancelled(CancelledException cex) {

            }

            @Override
            public void onFinished() {

            }
        });

        return update;
    }
}
