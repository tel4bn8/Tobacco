package com.nss.tobacco.activitymanagement;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CaremaAdapter;
import com.nss.tobacco.adapter.MyAdapter;
import com.nss.tobacco.daos.DBManager;
import com.nss.tobacco.entity.FarmerEntity;
import com.nss.tobacco.entity.Sec_XiaoduInfoEntity;
import com.nss.tobacco.utils.CommonUtil;
import com.nss.tobacco.utils.Constants;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;
import com.nss.tobacco.utils.IdcardInfoExtractor;
import com.nss.tobacco.utils.LocationUtils;
import com.nss.tobacco.utils.MyCallBack;
import com.nss.tobacco.utils.XUtil;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

@ContentView(R.layout.activity_add__xiaodu)
public class Add_XiaoduActivity extends AppCompatActivity implements View.OnClickListener{

    private String famer;
    private String createtime;
    private String yaoming;
    private String sheshi;
    private String detail;
    private String state;
    private DBManager dbManager;
    private String imagePath;
    //拍照
    Context context;
    private String location2;
    private static final int CRAEMA_REQUEST_CODE = 0; //拍照请求码

    private boolean candelete = false; //是否可以删除照片
    private String defaultPhotoAddress = null; //拍照生成默认照片的绝对路径
    private String photoFolderAddress = null; //存放照片的文件夹

    private List<String> listPhotoNames = null;
    private CaremaAdapter cadapter = null;
    private int screenWidth = 0; //屏幕宽度

    IdcardInfoExtractor extractor;

    @ViewInject(R.id.textView)
    TextView textView;
    @ViewInject(R.id.back_item)
    ImageView back_img;
    @ViewInject(R.id.frm_first_yn_ynda_add)
    ImageView ivPhoto;
    @ViewInject(R.id.caremaView)
    GridView caremaView;

    @ViewInject(R.id.spinner_zhongzhihu)
    Spinner sp_farmer;
    @ViewInject(R.id.shijian_text)
    TextView text_createtime;
    @ViewInject(R.id.spinner_yaoming)
    Spinner sp_yaoming;
    @ViewInject(R.id.spinner_sheshi)
    Spinner sp_sheshi;
    @ViewInject(R.id.biaozhun_pic)
    ImageView biaozhun;
    @ViewInject(R.id.beizhu_edit)
    EditText edit_detail;
    @ViewInject(R.id.btn_save)
    Button save;
    @ViewInject(R.id.btn_back)
    Button back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        dbManager = new DBManager(this);
        context = this;
        initView();
        setDate();
        mySpinner();
        initCarema();
        setListener();
        biaozhunPic();
    }
    private void biaozhunPic(){
       /* imagePath = "sdcard/Image/biaozhun.png";
        BitmapUtils bit = new BitmapUtils();
        biaozhun.setImageBitmap(bit.getImageThumbnail(imagePath, 100, 100));*/
        biaozhun.setImageResource(R.drawable.xiaodubiaozhun);
    }

    private void initView() {
        textView.setText("消毒");
    }
    private void initCarema() {
        //default photo address
        defaultPhotoAddress = CommonUtil.getSDPath() + File.separator + "default.jpg";
        //获取屏幕的分辨率
        DisplayMetrics dm = new DisplayMetrics();
        //取得窗口属性
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        //窗口的宽度
        screenWidth = dm.widthPixels;
        //是否可删除照片
        candelete = getIntent().getBooleanExtra("candelete", true);

        //获取文件夹名称
        if(getIntent().getStringExtra("folderName") == null){
            photoFolderAddress = CommonUtil.getSDPath() + File.separator + "TestPhotoFolder";
        }else{
            photoFolderAddress = getIntent().getStringExtra("folderName");
        }
        /*//加载历史照片
        loadHistoryPhoto(photoFolderAddress);*/
    }

    private void setListener() {
        back_img.setOnClickListener(this);
        ivPhoto.setOnClickListener(this);
        save.setOnClickListener(this);
        back_btn.setOnClickListener(this);
        biaozhun.setOnClickListener(this);
    }
    private void setDate(){
        //时间选择
        text_createtime.setText(GetDate.lastDay());
        text_createtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                DateDialog dialog = new DateDialog(Add_XiaoduActivity.this);
                dialog.setDate(text_createtime);
            }
        });
    }
    //自定义spinner
    private void mySpinner() {
        List<FarmerEntity> farmers=new ArrayList<FarmerEntity>();
        farmers.add(new FarmerEntity("张恒"));
        farmers.add(new FarmerEntity("舟山"));
        farmers.add(new FarmerEntity("王风"));
        farmers.add(new FarmerEntity("赵阳"));
        MyAdapter _MyAdapter=new MyAdapter(farmers,this);
        sp_farmer.setAdapter(_MyAdapter);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.age, R.layout.item_myspinner);
        sp_yaoming.setAdapter(adapter2);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,R.array.age, R.layout.item_myspinner);
        sp_sheshi.setAdapter(adapter3);
    }
    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                myDialog();
                break;
            case R.id.frm_first_yn_ynda_add:
                //验证sd卡是否可用
                if(CommonUtil.getSDPath() == null){
                    Toast.makeText(this, "请安装SD卡", Toast.LENGTH_SHORT).show();
                    return;
                }
                //验证是否超出限制照片数量
                if(listPhotoNames != null && listPhotoNames.size() >= Constants.MAX_PHOTO_SIZE){
                    Toast.makeText(context, "最多只允许拍摄" + Constants.MAX_PHOTO_SIZE + "张照片。", Toast.LENGTH_SHORT).show();
                    return;
                } //调用系统拍照
                intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT,Uri.fromFile(new File(defaultPhotoAddress)));
                startActivityForResult(intent, CRAEMA_REQUEST_CODE);
                break;

            case R.id.biaozhun_pic:
                //downloadPic();
                intent.setClass(this,Sec_Pic_Biaozhun_Activity.class);
                startActivity(intent);
                break;
            case R.id.btn_save:
                saveInfo();
                finish();
                break;
            case R.id.btn_back:
                myDialog();
                break;
            default:
                break;
        }
    }

    //下载图片
    private void downloadPic() {
        //文件下载地址
        String url = "http://192.168.1.103:8080/file/201611/1.png";
        //文件保存在本地的路径
        File file = new File("/sdcard/Image/");
        file.mkdirs();// 创建文件夹
        String path = "sdcard/Image/" + "biaozhun.png";
        XUtil.DownLoadFile(url, path,new MyCallBack<File>(){
            @Override
            public void onSuccess(File result) {
                super.onSuccess(result);
                Log.i("result", "--------xxxxxx"+result+"成功");
            }
            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                super.onError(ex, isOnCallback);
                Log.i("result", "--------xxxxxx"+"失败"+ex);
            }
        });
    }
    //保存录入信息到本地数据库
    private void saveInfo() {
        famer = sp_farmer.getSelectedItem().toString();
        createtime = text_createtime.getText().toString();
        yaoming = sp_yaoming.getSelectedItem().toString();
        sheshi = sp_sheshi.getSelectedItem().toString();
        detail = edit_detail.getText().toString();
        String str = "0";
        state = str;
        //创建消毒表 保存信息
        ArrayList<Sec_XiaoduInfoEntity> infoList = new ArrayList();
        Sec_XiaoduInfoEntity mXidoduInfoEntity = new Sec_XiaoduInfoEntity();
        mXidoduInfoEntity.farmer=famer;
        mXidoduInfoEntity.createtime=createtime;
        mXidoduInfoEntity.yaopin=yaoming;
        mXidoduInfoEntity.sheshi=sheshi;
        mXidoduInfoEntity.detail=detail;
        mXidoduInfoEntity.state=state;
        infoList.add(mXidoduInfoEntity);
        dbManager.add(infoList);
        Toast.makeText(this,"已经保存成功",Toast.LENGTH_LONG).show();
    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回",new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog"," 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
    //加载历史照片
    private void loadHistoryPhoto(String fileFolderAddr){
        File file = new File(fileFolderAddr);
        if(!file.exists() || !file.isDirectory()){
            return;
        }
        listPhotoNames = new ArrayList<String>();
        //获取照片内照片绝对路径集合
        String[] fileNames = file.list(new FilenameFilter() {
            public boolean accept(File afile, String name) {
                return name.endsWith(".jpg");
            }
        });
        for(String ipath : fileNames){
            listPhotoNames.add(photoFolderAddress + File.separator + ipath);
        }
        //加载照片
        cadapter = new CaremaAdapter(context, screenWidth, listPhotoNames, candelete);
        caremaView.setAdapter(cadapter);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK){
            switch (requestCode) {
                //拍照
                case CRAEMA_REQUEST_CODE:
                    //文件夹目录是否存在
                    File folderAddr = new File(photoFolderAddress);
                    if(!folderAddr.exists() || !folderAddr.isDirectory()){
                        folderAddr.mkdirs();
                    }
                    //将原图片压缩拷贝到指定目录
                    String targetPath = photoFolderAddress + File.separator + CommonUtil.getUUID32() + ".jpg";
                    location2 = "东经：" + LocationUtils.longitude + "北纬：" + LocationUtils.latitude + "   ";
                    CommonUtil.dealImage(defaultPhotoAddress, targetPath, location2);
                    //删除原图
                    new File(defaultPhotoAddress).delete();
                    //保存照片的绝对路径
                    if(listPhotoNames == null){
                        listPhotoNames = new ArrayList<String>();
                    }
                    listPhotoNames.add(targetPath);

                    if(cadapter == null){
                        cadapter = new CaremaAdapter(context, screenWidth, listPhotoNames, candelete);
                        caremaView.setAdapter(cadapter);
                    }else{
                        cadapter.notifyDataSetChanged();
                    }
                    break;
            }
        }
    }
}
