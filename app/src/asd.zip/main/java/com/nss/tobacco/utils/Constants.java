package com.nss.tobacco.utils;

public class Constants {
	
	public static final int MAX_PHOTO_SIZE = 4; //单次拍摄照片最大数
	public static final int MAX_NUM_COLUMNS = 4; // GridView展示照片列数
}
