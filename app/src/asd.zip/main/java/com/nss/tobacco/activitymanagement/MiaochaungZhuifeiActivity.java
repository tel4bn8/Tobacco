package com.nss.tobacco.activitymanagement;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CommonAdapter;
import com.nss.tobacco.adapter.ViewHolder;
import com.nss.tobacco.daos.Sec_MiaoChuangZhuiFeiDao;
import com.nss.tobacco.entity.Sec_MiaoChuangZhuiFeiEntity;
import com.nss.tobacco.utils.DividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class MiaochaungZhuifeiActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView textView;
    private ImageView back_img;
    private TextView add_text, upload;
    private Spinner year_spinner;
    private EditText search_edit;
    private Button search_btn;
    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipRefreshLayout;
    private List<String> mAllDatas, mSearchData;//RecyclerView数据库里的内容和根据条件查询的数据集合
    private Sec_MiaoChuangZhuiFeiDao mDBMiaoChuanZhuiFeiDao = null;

    //查询到的所有数据
    private List<Sec_MiaoChuangZhuiFeiEntity> allEntites;
    private List<Sec_MiaoChuangZhuiFeiEntity> searchEntities;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_miaochaung_zhuifei);
        initView();
        initData();
        myRecyclerView(mAllDatas);
        setLitsener();//监听事件
    }


    private void initView() {
        textView = (TextView) findViewById(R.id.textView_item);
        textView.setText("苗床追肥");
        back_img = (ImageView) findViewById(R.id.back_item);
        add_text = (TextView) findViewById(R.id.add_item);
        upload = (TextView) findViewById(R.id.up_item);
        year_spinner = (Spinner) findViewById(R.id.year_item);
        search_edit = (EditText) findViewById(R.id.searchbox);
        search_btn = (Button) findViewById(R.id.search_item);
        mRecyclerView = (RecyclerView) findViewById(R.id.second_ym_mczf_recyclerview);
        mSwipRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.second_ym_mczf_swipeRefresh);
        //初始化下拉刷新控件的颜色改变
        mSwipRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);
        mySpinner();
    }

    protected void initData() {
        mDBMiaoChuanZhuiFeiDao = new Sec_MiaoChuangZhuiFeiDao(this);
        //苗床追肥所有的数据
        mAllDatas = new ArrayList<>();
        allEntites = mDBMiaoChuanZhuiFeiDao.searchAll();
        for (Sec_MiaoChuangZhuiFeiEntity info : allEntites) {

            if (info.getState().equals("0")){
                mAllDatas.add(info.getCreatetime() + " " + info.getFarmer() +"                 "+"未上传");
            }else {
                mAllDatas.add(info.getCreatetime() + " " + info.getFarmer() +"                 "+"已上传");
            }

        }
    }

    private void myRecyclerView(final List<String> data) {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview,data) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.id_num,s);

                holder.setText(R.id.tv_state,s);
            }
            @Override
            public void onBindViewHolder(ViewHolder holder, final int position) {
                super.onBindViewHolder(holder, position);
                holder.setOnClickListener(R.id.id_num,new View.OnClickListener() {
                    @Override
                    public void onClick(View v){
                        Intent intent = new Intent();
                        intent.setClass(MiaochaungZhuifeiActivity.this, Sec_msg_MiaoChuangZhuiFei.class);
                        if(position<allEntites.size()&&searchEntities==null){
                            intent.putExtra("info", allEntites.get(position));
                            startActivity(intent);
                        }else{
                            intent.putExtra("info", searchEntities.get(position));
                            startActivity(intent);
                        }


                    }
                });


            }
        });
        //分割线
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL_LIST));
    }

    private void setLitsener() {
        back_img.setOnClickListener(this);
        add_text.setOnClickListener(this);
        upload.setOnClickListener(this);
        search_btn.setOnClickListener(this);
        mSwipRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initData();
                        myRecyclerView(mAllDatas);
                        mSwipRefreshLayout.setRefreshing(false);

                    }
                }, 3000);
            }
        });
    }

    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        Spinner spinner = (Spinner) findViewById(R.id.year_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.add_item:
                intent.setClass(this, Add_MiaoChuangZfActivity.class);
                startActivity(intent);
                break;
            case R.id.up_item:
                Toast.makeText(this, "已经上传成功", Toast.LENGTH_LONG).show();
                break;
            case R.id.year_item:

                break;
            case R.id.searchbox:

                break;
            //根据名字搜索
            case R.id.search_item:
                searchByName();
                break;
            default:
                break;
        }
    }

    //通过名字查询苗床追肥信息
    private void searchByName() {
        String name = search_edit.getText().toString();
        searchEntities = mDBMiaoChuanZhuiFeiDao.searchByName(name);
        mSearchData = new ArrayList<>();
        for (Sec_MiaoChuangZhuiFeiEntity info : searchEntities) {
            mSearchData.add(info.getCreatetime() + " " + info.getFarmer());
        }
        myRecyclerView(mSearchData);

    }
}
