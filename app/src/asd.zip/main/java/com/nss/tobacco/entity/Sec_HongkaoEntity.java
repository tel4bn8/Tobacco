package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建烘烤的表
 */
@Table(name = "hongkaoguanli")
public class Sec_HongkaoEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "starttime")
    private String starttime;
    @Column(name = "endtime")
    private String endtime;
    @Column(name = "part")
    private String part;
    @Column(name = "beforeweight")
    private String beforeweight;
    @Column(name = "afterweight")
    private String afterweight;
    @Column(name = "electric")
    private String electric;
    @Column(name = "coal")
    private String coal;
    @Column(name = "detail")
    private String detail;

    public Sec_HongkaoEntity() {
    }

    public Sec_HongkaoEntity(String id, String farmer, String starttime, String endtime, String part, String beforeweight, String afterweight, String electric, String coal, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.starttime = starttime;
        this.endtime = endtime;
        this.part = part;
        this.beforeweight = beforeweight;
        this.afterweight = afterweight;
        this.electric = electric;
        this.coal = coal;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getPart() {
        return part;
    }

    public void setPart(String part) {
        this.part = part;
    }

    public String getBeforeweight() {
        return beforeweight;
    }

    public void setBeforeweight(String beforeweight) {
        this.beforeweight = beforeweight;
    }

    public String getAfterweight() {
        return afterweight;
    }

    public void setAfterweight(String afterweight) {
        this.afterweight = afterweight;
    }

    public String getElectric() {
        return electric;
    }

    public void setElectric(String electric) {
        this.electric = electric;
    }

    public String getCoal() {
        return coal;
    }

    public void setCoal(String coal) {
        this.coal = coal;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Sec_HongkaoEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", starttime='" + starttime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", part='" + part + '\'' +
                ", beforeweight='" + beforeweight + '\'' +
                ", afterweight='" + afterweight + '\'' +
                ", electric='" + electric + '\'' +
                ", coal='" + coal + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
