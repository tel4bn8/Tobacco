package com.nss.tobacco.activitymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nss.tobacco.R;
import com.nss.tobacco.daos.WirelessQA;

public class Sec_msg_XiaoduActivity extends AppCompatActivity implements View.OnClickListener{
    private String result = null;
    private TextView textView,name,time,yaopin,sheshi,beizhu;
    private Button back;
    private ImageView back_img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_msg__xiaodu);
        initView();
        initData();
        setListener();
    }
    private void setListener() {
        back.setOnClickListener(this);
        back_img.setOnClickListener(this);
    }
    private void initView() {
        textView = (TextView) findViewById(R.id.textView);
        textView.setText("消毒");
        name = (TextView) findViewById(R.id.zhongzhihu);
        time = (TextView) findViewById(R.id.shijian);
        yaopin = (TextView) findViewById(R.id.yaoming);
        sheshi = (TextView) findViewById(R.id.sheshi);
        beizhu = (TextView) findViewById(R.id.beizhu);
        back = (Button) findViewById(R.id.btn_back);
        back_img = (ImageView) findViewById(R.id.back_item);
    }
    private void initData() {
        Bundle extras = getIntent().getExtras();
        result = extras.getString("searchResult");
        Log.i(WirelessQA.TAG, "-----------------eeeeeeeeeeeeee"+result);
        String[] msg = result.split(" ");
        if(msg.length==4){
            name.setText(msg[0]);
            Log.i(WirelessQA.TAG, "-----------------fffffffffffffff"+msg[0]);
            time.setText(msg[1]);
            yaopin.setText(msg[2]);
            sheshi.setText(msg[3]);
        }else{
            name.setText(msg[0]);
            Log.i(WirelessQA.TAG, "-----------------fffffffffffffff"+msg[0]);
            time.setText(msg[1]);
            yaopin.setText(msg[2]);
            sheshi.setText(msg[3]);
            beizhu.setText(msg[4]);
        }
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.back_item:
                finish();
                break;
            default:
                break;
        }
    }
}
