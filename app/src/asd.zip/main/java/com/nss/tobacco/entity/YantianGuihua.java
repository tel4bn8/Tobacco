package com.nss.tobacco.entity;

/**
 * Created by admin on 2016/11/7.
 */

public class YantianGuihua {

    public String id;
    public String village;
    public String year;
    public String area;
    public String lng;
    public String lat;
    public String dixing;
    public String tuzhi;
    public String soil;
    public String feili;
    public String moditime;
    public String technician;
    public String detail;

    public YantianGuihua(){}

    public YantianGuihua(String id, String village, String year, String area, String lng, String lat, String dixing,
                         String tuzhi, String soil, String feili, String moditime, String technician, String detail) {
        this.id = id;
        this.village = village;
        this.year = year;
        this.area = area;
        this.lng = lng;
        this.lat = lat;
        this.dixing = dixing;
        this.tuzhi = tuzhi;
        this.soil = soil;
        this.feili = feili;
        this.moditime = moditime;
        this.technician = technician;
        this.detail = detail;
    }
}
