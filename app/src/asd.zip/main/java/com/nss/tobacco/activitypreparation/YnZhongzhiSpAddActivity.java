package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.Map;

@ContentView(R.layout.activity_yn_zhongzhi_sp_add)
public class YnZhongzhiSpAddActivity extends AppCompatActivity implements View.OnClickListener{

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String,Object> map;
    private boolean isSave = false;//是否保存

    @ViewInject(R.id.textView)
    TextView textViewtitle;
    @ViewInject(R.id.back_item)
    ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_yn_zhongzhi_sp_add)
    ImageView ivPhoto;
    @ViewInject(R.id.frm_first_yn_zzsp_add_spinner_yannongName)
    Spinner spYannongName;
    @ViewInject(R.id.frm_first_yn_zzsp_add_spinner_leixing)
    Spinner spLeixing;
    @ViewInject(R.id.frm_first_yn_zzsp_add_edittext_zhongzhimianji)
    EditText etZhongzhimianji;
    @ViewInject(R.id.frm_first_yn_zzsp_add_textview_stopShengpi)
    TextView tvStopShenpi;
    @ViewInject(R.id.frm_first_yn_zzsp_add_spinner_shenpiniandu)
    Spinner spNiandu;
    @ViewInject(R.id.frm_first_yn_zzsp_add_textview_yanjiyuanShengpi)
    TextView tvYanjiyuanShenpi;
    @ViewInject(R.id.frm_first_yn_zzsp_add_textview_inputTime)
    TextView tvDengjiTime;
    @ViewInject(R.id.frm_first_yn_zzsp_add_edittext_beizhuxinxi)
    EditText etBeizhu;

    @ViewInject(R.id.frm_first_yn_zzsp_add_btnsave)
    Button btnSave;
    @ViewInject(R.id.frm_first_yn_zzsp_add_btnback)
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
        initListener();

        setDate();

        mySpinner();

        setEditListener();
    }

    private void setEditListener() {
        etZhongzhimianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etZhongzhimianji.getSelectionStart();
                editEnd = etZhongzhimianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etZhongzhimianji.setText(s);
                    etZhongzhimianji.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection2);
                }
            }
        });
    }

    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.yannongName, R.layout.item_myspinner);
        spYannongName.setAdapter(adapter1);
        String yannongName = spYannongName.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spNiandu.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.leixing, R.layout.item_myspinner);
        spLeixing.setAdapter(adapter3);
    }

    private void setDate() {
        String time = GetDate.lastDay();
        tvDengjiTime.setText(time);
        tvDengjiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YnZhongzhiSpAddActivity.this);
                dialog.setDate(tvDengjiTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("种植品种");

        //烟技员名字、烟站审批人名字
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.frm_first_yn_zhongzhi_sp_add:
                Toast.makeText(YnZhongzhiSpAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_zzsp_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YnZhongzhiSpAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_yn_zzsp_add_btnback:
                myDialog();
                break;
            default:
                break;
        }
    }
    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
