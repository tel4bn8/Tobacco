package com.nss.tobacco.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.nss.tobacco.entity.YantianGuihua;

import java.util.ArrayList;
import java.util.List;

/**
 * YantianGuihuaDao
 */

public class YantianGuihuaDao {

    private DBHelper helper;
    private SQLiteDatabase db;

    public YantianGuihuaDao(Context context){
        helper = new DBHelper(context);
        db = helper.getWritableDatabase();
    }

    /**
     * 向表中增加一个成员信息
     *
     * @param memberInfo
     */
    public void add(List<YantianGuihua> memberInfo){
        db.beginTransaction();
        try {
            for (YantianGuihua info : memberInfo){
                //向表中插入数据
                db.execSQL("INSERT INTO yantianguihua VALUES(null,?,?,?,?,?,?,?,?,?,?,?,?)",
                        new Object[]{ info.village, info.year, info.area, info.lng, info.lat,
                                info.dixing, info.tuzhi, info.soil, info.feili, info.moditime, info.technician, info.detail});
                db.setTransactionSuccessful();

            }

        }finally {
                db.endTransaction();
        }
    }



    /**
     * @param id
     * @param village
     * @param year
     * @param area
     * @param lng
     * @param lat
     * @param dixing
     * @param tuzhi
     * @param soil
     * @param feili
     * @param moditime
     * @param technician
     * @param detail
     */

    public void add(String id, String village,String year, String area, String lng,  String lat, String dixing,
                    String tuzhi,String soil, String feili, String moditime,  String technician, String detail){
        ContentValues cv = new ContentValues();

        cv.put("id", id);
        cv.put("village", village);
        cv.put("year", year);
        cv.put("area", area);
        cv.put("lng", lng);
        cv.put("lat", lat);
        cv.put("dixing", dixing);
        cv.put("tuzhi", tuzhi);
        cv.put("soil", soil);
        cv.put("feili", feili);
        cv.put("moditime", moditime);
        cv.put("technician", technician);
        cv.put("detail", detail);
        db.insert("yantianguihua", null, cv);
    }



    /**
     * 通过village来删除数据
     *
     * @param village
     */

    public void delData(String village){

        String[] args = { village };
        db.delete("yantianguihua", "village=?", args);
        Log.i(WirelessQA.TAG, "delete data by " + village);
    }



    /**
     * 清空数据
     */
    public void clearData() {

        ExecSQL("DELETE FROM yantianguihua");
        Log.i(WirelessQA.TAG, "clear data");
    }


    /**
     * 通过村庄查询信息,返回所有的数据
     *
     * @param village
     */
    public ArrayList<YantianGuihua> searchData(final String village) {
        String sql = "SELECT * FROM yantianguihua WHERE village =" + "'" + village + "'";
        return ExecSQLForMemberInfo(sql);
    }

    public ArrayList<YantianGuihua> searchAllData() {
        String sql = "SELECT * FROM yantianguihua";
        return ExecSQLForMemberInfo(sql);
    }


    /**
     * 通过村名来修改值
     *
     * @param raw
     * @param rawValue
     * @param whereName
     */
    public void updateData(String raw, String rawValue, String whereName) {
        String sql = "UPDATE yantianguihua SET " + raw + " =" + " " + "'" + rawValue + "'" + " WHERE village =" + "'" + whereName
                + "'";
        ExecSQL(sql);
        Log.i(WirelessQA.TAG, sql);
    }

    /**
     * 修改某一列的值
     *
     * @param raw
     * @param rawValue
     */
    public void updateLieData(String raw, String rawValue) {
        String sql = "UPDATE yantianguihua SET " + raw + " =" + " " + "'" + rawValue + "'" ;
        ExecSQL(sql);
        Log.i(WirelessQA.TAG, sql);
    }

    /**
     * 执行SQL命令返回list
     *
     * @param sql
     * @return
     */
    private ArrayList<YantianGuihua> ExecSQLForMemberInfo(String sql) {
        ArrayList<YantianGuihua> list = new ArrayList();
        Cursor c = ExecSQLForCursor(sql);
        while (c.moveToNext()) {
            YantianGuihua info = new YantianGuihua();
            info.id = c.getString(c.getColumnIndex("id"));
            info.village = c.getString(c.getColumnIndex("village"));
            info.year = c.getString(c.getColumnIndex("year"));
            info.area = c.getString(c.getColumnIndex("area"));
            info.lng = c.getString(c.getColumnIndex("lng"));
            info.lat = c.getString(c.getColumnIndex("lat"));
            info.dixing = c.getString(c.getColumnIndex("dixing"));
            info.tuzhi = c.getString(c.getColumnIndex("tuzhi"));
            info.soil = c.getString(c.getColumnIndex("soil"));
            info.feili = c.getString(c.getColumnIndex("feili"));
            info.moditime = c.getString(c.getColumnIndex("moditime"));
            info.technician = c.getString(c.getColumnIndex("technician"));
            info.detail = c.getString(c.getColumnIndex("detail"));
            list.add(info);
        }
        c.close();
        return list;
    }

    /**
     * 执行一个SQL语句
     *
     * @param sql
     */
    private void ExecSQL(String sql) {
        try {
            db.execSQL(sql);
            Log.i("execSql: ", sql);
        } catch (Exception e) {
            Log.e("ExecSQL Exception", e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 执行SQL，返回一个游标
     *
     * @param sql
     * @return
     */
    private Cursor ExecSQLForCursor(String sql) {
        Cursor c = db.rawQuery(sql, null);
        return c;
    }

    public void closeDB() {
        db.close();
    }
}
