package com.nss.tobacco.activitypreparation;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CaremaAdapter;
import com.nss.tobacco.daos.YantianGuihuaDao;
import com.nss.tobacco.entity.YantianGuihua;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;
import com.nss.tobacco.utils.IdUtil;
import com.nss.tobacco.utils.LocationUtils;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ContentView(R.layout.activity_wg_yantian_gh_add)
public class WgYantianGhAddActivity extends AppCompatActivity implements View.OnClickListener {

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String, Object> map;
    private boolean isSave = false;//是否保存

    //拍照
    Context context;
    private String location2;
    private static final int CRAEMA_REQUEST_CODE = 0; //拍照请求码
    private boolean candelete = false; //是否可以删除照片
    private String defaultPhotoAddress = null; //拍照生成默认照片的绝对路径
    private String photoFolderAddress = null; //存放照片的文件夹
    private List<String> listPhotoNames = null;
    private CaremaAdapter cadapter = null;
    private int screenWidth = 0; //屏幕宽度

    private String village;
    private String year;
    private String area;
    private String lng;
    private String lat;
    private String dixing;
    private String tuzhi;
    private String soil;
    private String feili;
    private String moditime;
    private String technician;
    private String detail;

    private YantianGuihuaDao yantianGuihuaDao;

    @ViewInject(R.id.textView)
    private TextView textViewtitle;
    @ViewInject(R.id.back_item)
    private ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_wg_yantian_gh_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_village)
    private Spinner spVillage;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_guhuaniandu)
    private Spinner spNiandu;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_edittext_mianji)
    private EditText etMianji;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_textview_jingdu)
    private TextView tvJingdu;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_textview_weidu)
    private TextView tvWeidu;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_dixing)
    private Spinner spDixing;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_tuzhileixing)
    private Spinner spTuzhileixing;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_turangfeili)
    private Spinner spTurangfeili;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_spinner_turangleixing)
    private Spinner spTurangleixing;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_textview_modiTime)
    private TextView tvModiTime;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_textview_yanjiyuan)
    private TextView tvYanjiyuan;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_edittext_beizhu)
    private EditText etBeizhu;


    @ViewInject(R.id.frm_first_wg_yantian_gh_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_wg_yantian_gh_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        yantianGuihuaDao = new YantianGuihuaDao(this);
        map = new HashMap<>();
        context = this;

        LocationUtils.initLocation(this);

        initView();
        initListener();
        setDate();
        mySpinner();
        setEditListener();

    }

    private void initListener() {//初始化监听

        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);

    }

    private void setEditListener() {//文本输入

        etMianji.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etMianji.getSelectionStart();
                editEnd = etMianji.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etMianji.setText(s);
                    etMianji.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection2 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection2);
                }
            }
        });
    }

    private void setDate() {//时间获取

        tvModiTime.setText(GetDate.lastDay());
        tvModiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(WgYantianGhAddActivity.this);
                dialog.setDate(tvModiTime);
            }
        });
    }

    private void initView() {
        textViewtitle.setText("烟田规划");
        //村名获取
        tvYanjiyuan.setText("寇晓恒");
        //经纬度获取
        LocationUtils.initLocation(this);

        tvJingdu.setText(LocationUtils.longitude+"");
        Log.i("lll", LocationUtils.latitude+"");
        tvWeidu.setText(LocationUtils.latitude+"");
    }

    private void mySpinner() {//
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.xingzhengquhua, R.layout.item_myspinner);
        spVillage.setAdapter(adapter1);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spNiandu.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.dixing, R.layout.item_myspinner);
        spDixing.setAdapter(adapter3);

        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.tuzhileixing, R.layout.item_myspinner);
        spTuzhileixing.setAdapter(adapter4);

        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this, R.array.turangfeili, R.layout.item_myspinner);
        spTurangfeili.setAdapter(adapter5);

        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this, R.array.turangleixing, R.layout.item_myspinner);
        spTurangleixing.setAdapter(adapter6);
    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                myDialog();
                break;
            case R.id.frm_first_wg_yantian_gh_add:
                Toast.makeText(this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_wg_yantian_gh_add_btnsave:
                savaInfo();
                Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
                finish();
                break;
            case R.id.frm_first_wg_yantian_gh_add_btnback:

                myDialog();

                break;
            default:
                break;
        }
    }

    private void savaInfo(){

        //spinner
        village = spVillage.getSelectedItem().toString();
        year = spNiandu.getSelectedItem().toString();
        dixing = spDixing.getSelectedItem().toString();
        tuzhi = spTuzhileixing.getSelectedItem().toString();
        feili = spTurangfeili.getSelectedItem().toString();
        soil = spTurangleixing.getSelectedItem().toString();

        //edittext
        area = etMianji.getText().toString();
        detail = etBeizhu.getText().toString();

        //textview
        lng = tvJingdu.getText().toString();
        lat = tvWeidu.getText().toString();
        moditime = tvModiTime.getText().toString();
        technician = tvYanjiyuan.getText().toString();

        ArrayList<YantianGuihua> infoList = new ArrayList<>();
        YantianGuihua yantianGuihua = new YantianGuihua();

        yantianGuihua.village = village;
        yantianGuihua.year = year;
        yantianGuihua.area = area;
        yantianGuihua.lng = lng;
        yantianGuihua.lat = lat;
        yantianGuihua.dixing = dixing;
        yantianGuihua.tuzhi = tuzhi;
        yantianGuihua.soil = soil;
        yantianGuihua.feili = feili;
        yantianGuihua.moditime = moditime;
        yantianGuihua.technician = technician;
        yantianGuihua.detail = detail;

        infoList.add(yantianGuihua);
        yantianGuihuaDao.add(infoList);
        Toast.makeText(this,"保存成功",Toast.LENGTH_LONG).show();
    }

    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}