package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建病虫防治的表
 */
@Table(name = "bingchongfangzhi")
public class Sec_BingchongFzEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "pesticide")
    private String pesticide;
    @Column(name = "way")
    private String way;
    @Column(name = "leaf")
    private String leaf;
    @Column(name = "type")
    private String type;
    @Column(name = "rate")
    private String rate;
    @Column(name = "area")
    private String area;
    @Column(name = "loss")
    private String loss;
    @Column(name = "detail")
    private String detail;
    @Column(name = "createtime")
    private String createtime;

    public Sec_BingchongFzEntity() {
    }

    public Sec_BingchongFzEntity(String id, String createtime, String detail, String loss, String area, String rate, String type, String leaf, String way, String pesticide, String farmer) {
        this.id = id;
        this.createtime = createtime;
        this.detail = detail;
        this.loss = loss;
        this.area = area;
        this.rate = rate;
        this.type = type;
        this.leaf = leaf;
        this.way = way;
        this.pesticide = pesticide;
        this.farmer = farmer;
    }

    public String getLoss() {
        return loss;
    }

    public void setLoss(String loss) {
        this.loss = loss;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLeaf() {
        return leaf;
    }

    public void setLeaf(String leaf) {
        this.leaf = leaf;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getPesticide() {
        return pesticide;
    }

    public void setPesticide(String pesticide) {
        this.pesticide = pesticide;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Sec_BingchongFzEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", pesticide='" + pesticide + '\'' +
                ", way='" + way + '\'' +
                ", leaf='" + leaf + '\'' +
                ", type='" + type + '\'' +
                ", rate='" + rate + '\'' +
                ", area='" + area + '\'' +
                ", loss='" + loss + '\'' +
                ", detail='" + detail + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
