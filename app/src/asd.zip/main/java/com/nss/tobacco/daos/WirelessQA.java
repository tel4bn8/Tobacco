package com.nss.tobacco.daos;

/**
 * Created by Administrator on 2016/11/17 0017.
 */


public class WirelessQA {
    public static final String TAG = "SQLite";

}