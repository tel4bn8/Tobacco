package com.nss.tobacco.activitypreparation;

import android.Manifest;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.util.Log;
import android.view.View;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.adapter.CommonAdapter;
import com.nss.tobacco.adapter.ViewHolder;
import com.nss.tobacco.daos.WirelessQA;
import com.nss.tobacco.daos.YantianGuihuaDao;
import com.nss.tobacco.entity.YantianGuihua;
import com.nss.tobacco.utils.DividerItemDecoration;
import com.nss.tobacco.utils.IdUtil;
import com.nss.tobacco.utils.PermissionHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WgYantianGhActivity extends AppCompatActivity implements View.OnClickListener{

    private List<String> mDatas,mDatas2;
    private CommonAdapter<String>  adapter, adapter2;
    private YantianGuihuaDao yantianGuihuaDao;
    private String[] words;
    private String mvillage;
    private Map<String,Object> map;
    private boolean mboolean = false;
    PermissionHelper mPermissionHelper;

    private ImageView imageViewback;
    private TextView textViewtitle, tvadd, tvupdata;
    private Spinner spinneryear;
    private EditText editTextsearch;
    private Button searchButton;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout wgYantianswipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_yantian_gh);
        yantianGuihuaDao = new YantianGuihuaDao(this);

        mPermissionHelper = new PermissionHelper(this);
        mPermissionHelper.checkPermisson(new PermissionHelper.OnPermissionListener() {
            @Override
            public void onAgreePermission() {
                Toast.makeText(WgYantianGhActivity.this, "同意权限了", Toast.LENGTH_SHORT).show();
                // do something
            }

            @Override
            public void onDeniedPermission() {
                Toast.makeText(WgYantianGhActivity.this, "拒绝权限了", Toast.LENGTH_SHORT).show();
                finish(); // 当界面一定通过权限才能继续，就要加上这行
            }
        }, Manifest.permission.ACCESS_FINE_LOCATION);

        initView();
        initData();
        initRecyclerView();
        init();
        initListener();
    }

    private void init() {

        wgYantianswipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);
        wgYantianswipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        wgYantianswipeRefreshLayout.measure(0,0);
                        wgYantianswipeRefreshLayout.setRefreshing(true);
                        initData();
                        initRecyclerView();
                        adapter.notifyDataSetChanged();
                        if (wgYantianswipeRefreshLayout.isRefreshing()) {
                            wgYantianswipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }, 3000);
            }
        });
    }
    //初始化数据
    private void initData() {
        mDatas = new ArrayList<String>();

        ArrayList<YantianGuihua> infoList = new ArrayList<YantianGuihua>();

        infoList = yantianGuihuaDao.searchAllData();
        for (YantianGuihua info : infoList){
            map=new HashMap<>();
            String id = IdUtil.getId();
            map.put("id",id);

            map.put("year",info.year);
            map.put("area",info.area);
            map.put("lng",info.lng);
            map.put("lat",info.lat);
            map.put("dixing",info.dixing);
            map.put("tuzhi",info.tuzhi);
            map.put("soil",info.soil);
            map.put("feili",info.feili);
            map.put("moditime",info.moditime);
            map.put("technician",info.technician);
            map.put("detail",info.detail);
            Log.i("result","--------ppppppppppppp"+ map.toString());

            mDatas.add(0,info.moditime+" "+info.village);

        }
    }

    private void initRecyclerView() {

        recyclerView = (RecyclerView) findViewById(R.id.frm_first_wg_yantian_gh_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //添加数据
        recyclerView.setAdapter(new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview, mDatas) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.id_num,s);
            }

            @Override
            public void onBindViewHolder(ViewHolder holder, final int position) {
                super.onBindViewHolder(holder, position);
                holder.setOnClickListener(R.id.id_num, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDatas.get(position);
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mDatas.get(position));
                        words = mDatas.get(position).split(" ");
                        mvillage = words[1];
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mvillage);
                        String time = words[0];
                        Toast.makeText(getApplicationContext(),"aaaaa"+position,Toast.LENGTH_LONG).show();
                        searchByname();
                    }
                });
            }
        });
        recyclerView.setAdapter(adapter);
        //分割线
        recyclerView.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL_LIST));
    }

    //查询数据库传递详细信息跳转页面
    private void searchByname() {
        ArrayList<YantianGuihua> infoList = new ArrayList<>();
        infoList = yantianGuihuaDao.searchData(mvillage);
        String result = null;
        for (YantianGuihua info : infoList) {
            result = info.village + " " + info.year + " " + info.area + " " + info.lng+ " " +info.lat + " " + info.dixing + " " + info.tuzhi
                    + " " + info.soil + " " + info.feili + " " + info.moditime + " " + info.technician + " " + info.detail;
        }
        Log.i(WirelessQA.TAG, "-----------------ddddd"+result);
        startMsg_WgYantianGhActivity("searchResult", result);
    }

    private void startMsg_WgYantianGhActivity(String intentName, String intentValue) {
        Intent intent = new Intent(this, Msg_WgYantianGhActivity.class);
        intent.putExtra(intentName, intentValue);
        startActivity(intent);
    }

    //初始化普通点击监听
    private void initListener() {

        imageViewback.setOnClickListener(this);

        tvadd.setOnClickListener(this);
        tvupdata.setOnClickListener(this);

        searchButton.setOnClickListener(this);
    }

    //初始化view
    private void initView() {
        //标题栏
        imageViewback = (ImageView) findViewById(R.id.back_item);
        textViewtitle = (TextView) findViewById(R.id.textView_item);
        wgYantianswipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.frm_first_wg_yantian_gh_swipe);
        textViewtitle.setText("烟田规划");
        tvadd = (TextView) findViewById(R.id.add_item);
        tvupdata = (TextView) findViewById(R.id.up_item);
        //搜索栏
        spinneryear = (Spinner) findViewById(R.id.frm_first_time_spinner);
        mySpinner();
        editTextsearch = (EditText) findViewById(R.id.frm_first_edittext);
        searchButton = (Button) findViewById(R.id.search_button_item);
    }

    //自定义spinner
    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.year_item, R.layout.item_myspinner);
        spinneryear.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_item:
                finish();
                break;
            case R.id.add_item:
                Intent intent = new Intent(WgYantianGhActivity.this, WgYantianGhAddActivity.class);
                startActivity(intent);
                break;
            case R.id.up_item:
                Toast.makeText(this,"上传成功",Toast.LENGTH_LONG).show();
                break;
            case R.id.frm_first_time_spinner:

                break;
            case R.id.frm_first_edittext:

                break;
            case R.id.search_button_item:
                //搜索监听
                searchMyRecy();
                break;
            default:
                break;
        }
    }

    /*private void updateState() {
        String state = "1";
        yantianGuihuaDao.updateLieData("state",state);
    }*/

    //上传数据
    /*private void post() {
        String url="";
        XUtil.Post(url, map, new MyCallBack<String>(){
            @Override
            public void onSuccess(String result) {
                super.onSuccess(result);
                Log.i("result", "--------www"+result+"成功");
            }
            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                super.onError(ex, isOnCallback);
                Log.i("result", "--------www"+"失败");
            }
        });
    }*/

    //搜索功能
    private void searchMyRecy() {

        String str = editTextsearch.getText().toString();
        Log.i("aaa",  "cccccccccccccccccc2"+str);
        ArrayList<YantianGuihua> infoList = new ArrayList<YantianGuihua>();
        infoList = yantianGuihuaDao.searchAllData();
        mDatas2 = new ArrayList<String>();
        for (YantianGuihua info2 : infoList) {
            if (info2.village.equals(str)){
                mDatas2.add(info2.moditime+" "+info2.village);
                Log.i("aaa",  "cccccccccccccccccc2"+info2.moditime+info2.soil+info2.tuzhi+info2.feili);
            }
        }
        adapter2 = new CommonAdapter<String>(this, R.layout.item_detailmsg_recyclerview, mDatas2) {
            @Override
            public void convert(ViewHolder holder, String s) {
                holder.setText(R.id.id_num,s);
                //holder.setText(R.id.id_num2,"未上传");
            }

            @Override
            public void onBindViewHolder(final ViewHolder holder, final int position) {
                super.onBindViewHolder(holder, position);
                holder.setOnClickListener(R.id.id_num, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDatas2.get(position);
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mDatas2.get(position));
                        words = mDatas2.get(position).split(" ");
                        mvillage = words[1];
                        Log.i("aaa", "aaaaaaaaaaaaaaaaaaaa"+mvillage);
                        String time = words[0];
                        Toast.makeText(getApplicationContext(),"ttttt"+position,Toast.LENGTH_LONG).show();
                        searchByname();
                    }
                });
            }
        };

        recyclerView.setAdapter(adapter2);
    }

    @Override
    public void onResume() {
        super.onResume();
        mPermissionHelper.onResume(); // 当界面一定通过权限才能继续，就要加上这行
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mPermissionHelper.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}