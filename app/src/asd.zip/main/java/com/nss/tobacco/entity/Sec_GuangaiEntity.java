package com.nss.tobacco.entity;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * Created by Administrator on 2016/11/8 0008.
 * 创建灌溉的表
 */
@Table(name = "yantianguangai")
public class Sec_GuangaiEntity {
    @Column(name = "id",isId = true, autoGen = true)
    private String id;
    @Column(name = "farmer")
    private String farmer;
    @Column(name = "worktime")
    private String worktime;
    @Column(name = "way")
    private String way;
    @Column(name = "area")
    private String area;
    @Column(name = "detail")
    private String detail;

    public Sec_GuangaiEntity() {
    }

    public Sec_GuangaiEntity(String id, String farmer, String way, String worktime, String area, String detail) {
        this.id = id;
        this.farmer = farmer;
        this.way = way;
        this.worktime = worktime;
        this.area = area;
        this.detail = detail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmer() {
        return farmer;
    }

    public void setFarmer(String farmer) {
        this.farmer = farmer;
    }

    public String getWorktime() {
        return worktime;
    }

    public void setWorktime(String worktime) {
        this.worktime = worktime;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Sec_GuangaiEntity{" +
                "id='" + id + '\'' +
                ", farmer='" + farmer + '\'' +
                ", worktime='" + worktime + '\'' +
                ", way='" + way + '\'' +
                ", area='" + area + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
