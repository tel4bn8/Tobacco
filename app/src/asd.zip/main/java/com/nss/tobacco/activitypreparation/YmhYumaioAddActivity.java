package com.nss.tobacco.activitypreparation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.nss.tobacco.R;
import com.nss.tobacco.utils.DateDialog;
import com.nss.tobacco.utils.GetDate;
import com.nss.tobacco.utils.IdcardInfoExtractor;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.Map;

@ContentView(R.layout.activity_ymh_yumaio_add)
public class YmhYumaioAddActivity extends AppCompatActivity implements View.OnClickListener {

    private CharSequence temp;
    private int editStart;
    private int editEnd;
    private Map<String, Object> map;

    IdcardInfoExtractor extractor;

    @ViewInject(R.id.textView)
    private TextView textViewtitle;
    @ViewInject(R.id.back_item)
    private ImageView ivtitleBack;

    @ViewInject(R.id.frm_first_ymh_ymh_add)
    private ImageView ivPhoto;
    @ViewInject(R.id.frm_first_ymh_ymh_add_edittext_Name)
    private EditText etName;
    @ViewInject(R.id.frm_first_ymh_ymh_add_edittext_IDcardNum)
    private EditText etIDcardNum;
    @ViewInject(R.id.frm_first_ymh_ymh_add_textview_age)
    private TextView tvAge;
    @ViewInject(R.id.frm_first_ymh_ymh_add_textview_sex)
    private TextView tvSex;
    @ViewInject(R.id.frm_first_ymh_ymh_add_edittext_phoneNum)
    private EditText etPhoneNum;
    @ViewInject(R.id.frm_first_ymh_ymh_add_spinner_cultureLevel)
    private Spinner spCultureLevel;
    @ViewInject(R.id.frm_first_ymh_ymh_add_spinner_zhongzhiYears)
    private Spinner spZhongzhiYears;
    @ViewInject(R.id.frm_first_ymh_ymh_add_spinner_HomeAddress)
    private Spinner spHomeAddress;
    @ViewInject(R.id.frm_first_ymh_ymh_add_textview_yanjiyuan)
    private TextView tvYanjiyuan;
    @ViewInject(R.id.frm_first_ymh_ymh_add_textview_stop)
    private TextView tvStop;
    @ViewInject(R.id.frm_first_ymh_ymh_add_textview_inputTime)
    private TextView tvDengjiTime;
    @ViewInject(R.id.frm_first_ymh_ymh_add_edittext_beizhu)
    private EditText etBeizhu;

    @ViewInject(R.id.frm_first_ymh_ymh_add_btnsave)
    private Button btnSave;
    @ViewInject(R.id.frm_first_ymh_ymh_add_btnback)
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
        initListener();

        setDate();

        mySpinner();

        setEditListener();
    }

    private void setEditListener() {
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etName.getSelectionStart();
                editEnd = etName.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etName.setText(s);
                    etName.setSelection(tempSelection1);
                }
            }
        });
        etIDcardNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                extractor = new IdcardInfoExtractor(s.toString());
                String age = extractor.getAge() + "";
                tvAge.setText(age);

                String sex = extractor.getGender();
                tvSex.setText(sex);

                editStart = etIDcardNum.getSelectionStart();
                editEnd = etIDcardNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etIDcardNum.setText(s);
                    etIDcardNum.setSelection(tempSelection1);
                }
            }
        });
        etPhoneNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etPhoneNum.getSelectionStart();
                editEnd = etPhoneNum.getSelectionEnd();
                if (temp.length() > 10) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etPhoneNum.setText(s);
                    etPhoneNum.setSelection(tempSelection1);
                }
            }
        });
        etBeizhu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                editStart = etBeizhu.getSelectionStart();
                editEnd = etBeizhu.getSelectionEnd();
                if (temp.length() > 50) {//限制长度
                    Toast.makeText(getApplicationContext(),
                            "输入的字数已经超过了限制！", Toast.LENGTH_SHORT)
                            .show();
                    s.delete(editStart - 1, editEnd);
                    int tempSelection1 = editStart;
                    etBeizhu.setText(s);
                    etBeizhu.setSelection(tempSelection1);
                }
            }
        });
    }

    private void mySpinner() {
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.wenhua, R.layout.item_myspinner);
        spCultureLevel.setAdapter(adapter1);
        String village = spCultureLevel.getSelectedItem().toString();

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.year_item, R.layout.item_myspinner);
        spZhongzhiYears.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.xingzhengquhua, R.layout.item_myspinner);
        spHomeAddress.setAdapter(adapter3);

    }

    private void setDate() {
        String time = GetDate.lastDay();
        tvDengjiTime.setText(time);
        tvDengjiTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DateDialog dialog = new DateDialog(YmhYumaioAddActivity.this);
                dialog.setDate(tvDengjiTime);
            }
        });
    }

    private void initListener() {
        ivPhoto.setOnClickListener(this);
        ivtitleBack.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initView() {
        textViewtitle.setText("育苗户");

    }

    @Override
    public void onClick(View v) {
        //添加点击事件
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.back_item:
                finish();
                break;
            case R.id.frm_first_ymh_ymh_add:
                Toast.makeText(YmhYumaioAddActivity.this, "拍照", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_ymh_add_btnsave:
                //uploadfile();
                //post();
                Toast.makeText(YmhYumaioAddActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.frm_first_ymh_ymh_add_btnback:
                myDialog();
                break;
            default:
                break;
        }
    }

    //返回按钮提醒框
    private void myDialog() {
        new AlertDialog.Builder(this).setTitle("系统提示")//设置对话框标题
                .setMessage("未保存，确认退出吗？")//设置显示的内容
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {//添加确定按钮
                    @Override
                    public void onClick(DialogInterface dialog, int which) {//确定按钮的响应事件
                        // TODO Auto-generated method stub
                        finish();
                    }
                }).setNegativeButton("返回", new DialogInterface.OnClickListener() {//添加返回按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {//响应事件
                // TODO Auto-generated method stub
                Log.i("alertdialog", " 请保存数据！");
            }
        }).show();//在按键响应事件中显示此对话框
    }
}
