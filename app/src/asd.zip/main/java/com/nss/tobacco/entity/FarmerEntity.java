package com.nss.tobacco.entity;

/**
 * Created by Administrator on 2016/11/19 0019.
 */

public class FarmerEntity {
    private String name;

    public FarmerEntity(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
