package com.nss.tobacco.daos;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.nss.tobacco.MyApp;
import com.nss.tobacco.entity.Sec_HongkaoEntity;

import org.xutils.DbManager;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.List;

/**
 * Created by Administrator on 2016/11/12 0012.
 */

public class Sec_HongkaoDao {
    public static boolean isSave;
    public static boolean isUpdate;
    private Context context;
    private final static DbManager manager= x.getDb(new MyApp().getDaoConfig());
    public final static String ACTION="SAVEORUPDATEFINISH";

    public Sec_HongkaoDao(Context context) {
        this.context = context;
    }
    //保存数据到数据库
    public  boolean saveInfo(Sec_HongkaoEntity hongkaoInfo){
        try {
            isSave=manager.saveBindingId(hongkaoInfo);
            sendFinishBroad();
            return isSave;
        } catch (DbException e) {
            e.printStackTrace();
        }
        return false;
    }
    //查询数据
    public Sec_HongkaoEntity getInfo(String farmer){
        Sec_HongkaoEntity getInfo=null;
        try {
            getInfo= manager.findById(Sec_HongkaoEntity.class,farmer);
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
        return getInfo;
    }
    //查询第一个数据
    public Sec_HongkaoEntity getInfoFromDb(){
        Sec_HongkaoEntity info=null;
        try {
            info= manager.findFirst(Sec_HongkaoEntity.class);
        } catch (DbException e) {
            e.printStackTrace();
        }
        return info;
    }
    //查询所有的数据
    public void getAll(){
        try {
            List<Sec_HongkaoEntity> list = manager.findAll(Sec_HongkaoEntity.class);
            for (Sec_HongkaoEntity info:list){
                Log.i("getAll",info.toString());
            }
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

    //更新数据
    public void upInfo(Sec_HongkaoEntity hongkaoInfo){

        try {
            manager.saveOrUpdate(hongkaoInfo);
            isUpdate=true;
            sendFinishBroad();
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //增加列数
    public void addColum(String newColum){
        try {
            manager.addColumn(Sec_HongkaoEntity.class,newColum);
        } catch (DbException e) {
            e.printStackTrace();
        }
    }
    //发送广播
    public void sendFinishBroad(){
        Intent intent=new Intent();
        intent.setAction(ACTION);
        context.sendBroadcast(intent);
    }
}
