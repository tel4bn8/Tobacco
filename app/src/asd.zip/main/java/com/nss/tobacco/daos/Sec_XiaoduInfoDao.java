package com.nss.tobacco.daos;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.nss.tobacco.MyApp;
import com.nss.tobacco.entity.Sec_XiaoduInfoEntity;

import org.xutils.DbManager;
import org.xutils.db.Selector;
import org.xutils.db.sqlite.SqlInfo;
import org.xutils.db.table.DbModel;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/11/6 0007.
 */

public class Sec_XiaoduInfoDao {
    private DBHelper       helper;
    private SQLiteDatabase db;

}
